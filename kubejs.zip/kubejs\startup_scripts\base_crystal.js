StartupEvents.registry('item', event => {
    event.create('base_crystal')
        .displayName('§bCristal de Base')
        .tooltip('§7Clic derecho para vincular tu base actual.')
        .tooltip('§7Úsalo de nuevo para teletransportarte.')
        .tooltip('§8Se desgasta con cada teletransporte (50 usos).')
        .glow(true)
        .texture('minecraft:item/amethyst_shard')
        .maxDamage(50);
});
