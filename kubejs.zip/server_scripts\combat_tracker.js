// combat_tracker.js
// Rastrea cuándo un jugador entra en combate para restringir el uso de ciertos ítems

EntityEvents.hurt(event => {
    const entity = event.entity;
    const source = event.source.actual;
    
    const currentTime = new Date().getTime();
    
    // Si la entidad que recibe daño es un jugador, ponerlo en combate
    if (entity.isPlayer()) {
        entity.persistentData.putLong('lastCombatTime', currentTime);
    }
    
    // Si la entidad que causa el daño es un jugador, también ponerlo en combate
    if (source && source.isPlayer()) {
        source.persistentData.putLong('lastCombatTime', currentTime);
    }
});
