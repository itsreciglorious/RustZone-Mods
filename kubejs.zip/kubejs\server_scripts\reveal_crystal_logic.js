ItemEvents.rightClicked('kubejs:reveal_crystal', event => {
    const { player, item, level } = event;
    
    // Solo ejecutar en el lado del servidor
    if (level.isClientSide()) return;
    
    // Play a breaking sound at player's location
    level.playSound(null, player.x, player.y, player.z, 'minecraft:block.amethyst_block.break', 'players', 1.0, 1.0);
    
    // Consume el ítem (resta 1)
    item.count--;
    
    let revealedCount = 0;
    const radius = 30; // 30 bloques según solicitado
    const durationTicks = 5 * 20; // 5 segundos
    
    // Obtener jugadores cercanos en el radio de 30 bloques
    let nearbyPlayers = level.getEntitiesWithinRadius('minecraft:player', player.x, player.y, player.z, radius);
    
    nearbyPlayers.forEach(target => {
        // Asegurarnos de que no sea el mismo jugador que usó el ítem
        if (target.uuid !== player.uuid) {
            // Verificar si el objetivo es invisible
            if (target.hasEffect('minecraft:invisibility')) {
                // Aplicar efecto Glowing (brillo)
                // Sintaxis: add(effect, durationTicks, amplifier, ambient, visible)
                target.potionEffects.add('minecraft:glowing', durationTicks, 0, false, false);
                
                revealedCount++;
                
                // Notificar al jugador que fue revelado (mensaje rojo y sonido de alerta)
                target.tell(Text.red('¡HAS SIDO REVELADO! Alguien ha usado un Cristal Revelador cercano.'));
                // Reproducir un sonido intimidante/peligro
                target.playSound('minecraft:entity.wither.spawn', 0.5, 1.5);
            }
        }
    });
    
    // Feedback al jugador que lo usó
    if (revealedCount > 0) {
        player.tell(Text.green(`¡El cristal se rompió y ha revelado a ${revealedCount} jugador(es) invisible(s) en tu zona!`));
    } else {
        player.tell(Text.yellow('El cristal se rompió pero no detectó a ningún jugador invisible en tu zona.'));
    }
});
