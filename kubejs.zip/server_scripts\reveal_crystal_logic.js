ItemEvents.rightClicked('kubejs:reveal_crystal', event => {
    try {
        var rc_player = event.player;
        var rc_item = event.item;
        var rc_level = event.level;
        
        // Solo ejecutar en el lado del servidor
        if (rc_level.isClientSide()) return;
        
        // Play a breaking sound at player's location
        rc_level.playSound(null, rc_player.x, rc_player.y, rc_player.z, 'minecraft:block.amethyst_block.break', 'players', 1.0, 1.0);
        
        // Consume el ítem (resta 1)
        rc_item.count--;
        
        var rc_revealedCount = 0;
        var rc_radius = 30; // 30 bloques según solicitado
        var rc_durationTicks = 5 * 20; // 5 segundos
        
        // Obtener jugadores cercanos en el radio de 30 bloques
        var rc_nearbyPlayers = rc_level.getPlayers().filter(p => {
            var dx = p.x - rc_player.x;
            var dy = p.y - rc_player.y;
            var dz = p.z - rc_player.z;
            return Math.sqrt(dx*dx + dy*dy + dz*dz) <= rc_radius;
        });
        
        rc_nearbyPlayers.forEach(target => {
            // Asegurarnos de que no sea el mismo jugador que usó el ítem
            if (target.uuid !== rc_player.uuid) {
                // Verificar si el objetivo es invisible
                if (target.hasEffect('minecraft:invisibility')) {
                    // Aplicar efecto Glowing (brillo)
                    // Sintaxis: add(effect, durationTicks, amplifier, ambient, visible)
                    target.potionEffects.add('minecraft:glowing', rc_durationTicks, 0, false, false);
                    
                    rc_revealedCount++;
                    
                    // Notificar al jugador que fue revelado (mensaje rojo y sonido de alerta)
                    target.tell(Text.red('¡HAS SIDO REVELADO! Alguien ha usado un Cristal Revelador cercano.'));
                    // Reproducir un sonido intimidante/peligro
                    target.playSound('minecraft:entity.wither.spawn', 0.5, 1.5);
                }
            }
        });
        
        // Feedback al jugador que lo usó
        if (rc_revealedCount > 0) {
            rc_player.tell(Text.green(`¡El cristal se rompió y ha revelado a ${rc_revealedCount} jugador(es) invisible(s) en tu zona!`));
            rc_player.playSound('minecraft:entity.evoker.prepare_summon', 1.0, 1.0);
            rc_player.runCommandSilent(`title ${rc_player.username} subtitle {"text":"${rc_revealedCount} jugador(es) detectado(s)","color":"red"}`);
            rc_player.runCommandSilent(`title ${rc_player.username} title {"text":"¡ADVERTENCIA!","color":"dark_red","bold":true}`);
        } else {
            rc_player.tell(Text.yellow('El cristal se rompió pero no detectó a ningún jugador invisible en tu zona.'));
            rc_player.playSound('minecraft:block.note_block.bass', 1.0, 1.0);
        }
    } catch (e) {
        console.error('ERROR IN REVEAL CRYSTAL: ' + e);
        if (event && event.player) event.player.tell(Text.red('ERROR IN REVEAL CRYSTAL: ' + e));
    }
});
