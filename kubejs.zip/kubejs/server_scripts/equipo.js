// priority: 10
console.info('Loaded equipo.js');

if (typeof global.friendlyFireEnabled === 'undefined') {
    global.friendlyFireEnabled = false; // By default, friendly fire is disabled (protection active)
}

ServerEvents.commandRegistry(event => {
    const { commands: Commands, arguments: Arguments } = event;

    // Command: /equipo
    event.register(
        Commands.literal("equipo")
            .executes(ctx => {
                const player = ctx.source.player;
                if (player) {
                    console.log("[EQUIPO-KJS] " + player.username + " issued command: /equipo");
                    player.tell(Text.gray("[Equipo] Obteniendo información del equipo..."));
                }
                return 1;
            })
    );

    // Command: /sync-player-team <player> <teamId> <teamName> (RCON/Console Only)
    event.register(
        Commands.literal("sync-player-team")
            .requires(src => src.hasPermission(4))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .then(Commands.argument("teamId", Arguments.INTEGER.create(event))
                    .then(Commands.argument("teamName", Arguments.GREEDY_STRING.create(event))
                        .executes(ctx => {
                            var username = Arguments.STRING.getResult(ctx, "player");
                            var teamId = Arguments.INTEGER.getResult(ctx, "teamId");
                            var teamName = Arguments.GREEDY_STRING.getResult(ctx, "teamName");
                            
                            var server = ctx.source.server;
                            var player = server.players.find(function(p) {
                                return p.username.toLowerCase() === username.toLowerCase();
                            });
                            
                            if (player) {
                                player.persistentData.putInt('teamId', teamId);
                                player.persistentData.putString('teamName', teamName);
                                // Trigger tablist prefix refresh
                                if (typeof updatePlayerTabName === 'function') {
                                    updatePlayerTabName(player);
                                }
                                console.info("[SYNC-PLAYER-TEAM-DONE] " + player.username + " synced to team " + teamId + " (" + teamName + ")");
                            }
                            return 1;
                        })
                    )
                )
            )
    );

    // Command: /sync-friendly-fire <true/false> (RCON/Console Only)
    event.register(
        Commands.literal("sync-friendly-fire")
            .requires(src => src.hasPermission(4))
            .then(Commands.argument("enabled", Arguments.STRING.create(event))
                .executes(ctx => {
                    var enabledStr = Arguments.STRING.getResult(ctx, "enabled");
                    global.friendlyFireEnabled = (enabledStr.toLowerCase() === "true");
                    console.info("[SYNC-FRIENDLY-FIRE] Friendly Fire set to: " + global.friendlyFireEnabled);
                    return 1;
                })
            )
    );
});

// Friendly Fire Protection: Cancel damage between players on the same team
EntityEvents.hurt(event => {
    var source = event.source;
    var entity = event.entity;
    if (!source || !entity) return;

    if (entity.isPlayer() && source.actualEntity && source.actualEntity.isPlayer()) {
        var player = entity;
        var attacker = source.actualEntity;

        var playerTeam = player.persistentData.getInt('teamId') || 0;
        var attackerTeam = attacker.persistentData.getInt('teamId') || 0;

        if (playerTeam > 0 && attackerTeam > 0 && playerTeam === attackerTeam) {
            if (!global.friendlyFireEnabled) {
                event.cancel();
                attacker.tell(Text.red("§c[Equipo] No puedes dañar a tus compañeros de equipo."));
            }
        }
    }
});

// Team Glow Effect Tick: Give teammates green glow and update their scoreboard team color
ServerEvents.tick(event => {
    var srv = event.server;
    if (srv.tickCount % 40 === 0) { // Every 2 seconds
        var onlinePlayers = srv.players;
        for (var i = 0; i < onlinePlayers.length; i++) {
            var player = onlinePlayers[i];
            var teamId = player.persistentData.getInt('teamId') || 0;
            
            if (teamId > 0) {
                // Set their individual tablist team color to green so their glow outline is green
                var individualTeam = "lp_" + player.username;
                srv.runCommandSilent("team modify " + individualTeam + " color green");
                
                // Give them the glowing effect silently
                srv.runCommandSilent("effect give " + player.username + " minecraft:glowing 5 0 true");
            }
        }
    }
});
