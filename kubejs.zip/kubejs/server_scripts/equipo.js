// priority: 10
console.info('Loaded equipo.js');

if (typeof global.friendlyFireEnabled === 'undefined') {
    global.friendlyFireEnabled = false; // By default, friendly fire is disabled (protection active)
}
if (typeof global.pvpEnabled === 'undefined') {
    global.pvpEnabled = true; // By default, PvP is enabled (matching server.properties)
}

ServerEvents.commandRegistry(event => {
    const { commands: Commands, arguments: Arguments } = event;

    // Command: /equipo (Accessible by all players)
    event.register(
        Commands.literal("equipo")
            .requires(src => src.hasPermission(0))
            .executes(ctx => {
                const player = ctx.source.player;
                if (player) {
                    console.info("[EQUIPO-KJS] " + player.username + " issued command: /equipo");
                    player.tell(Text.gray("[Equipo] Obteniendo información detallada de la base de datos..."));
                }
                return 1;
            })
    );

    // Command: /sync-player-team <player> <teamId> <teamName> (RCON/Console Only)
    event.register(
        Commands.literal("sync-player-team")
            .requires(src => src.hasPermission(4))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .then(Commands.argument("teamId", Arguments.INTEGER.create(event))
                    .then(Commands.argument("teamName", Arguments.GREEDY_STRING.create(event))
                        .executes(ctx => {
                            var username = Arguments.STRING.getResult(ctx, "player");
                            var teamId = Arguments.INTEGER.getResult(ctx, "teamId");
                            var teamName = Arguments.GREEDY_STRING.getResult(ctx, "teamName");
                            
                            var server = ctx.source.server;
                            var player = server.players.find(function(p) {
                                return p.username.toLowerCase() === username.toLowerCase();
                            });
                            
                            if (player) {
                                player.persistentData.putInt('teamId', teamId);
                                player.persistentData.putString('teamName', teamName);
                                // Trigger tablist prefix refresh
                                if (typeof updatePlayerTabName === 'function') {
                                    updatePlayerTabName(player);
                                }
                                console.info("[SYNC-PLAYER-TEAM-DONE] " + player.username + " synced to team " + teamId + " (" + teamName + ")");
                            }
                            return 1;
                        })
                    )
                )
            )
    );

    // Command: /sync-friendly-fire <true/false> (RCON/Console Only)
    event.register(
        Commands.literal("sync-friendly-fire")
            .requires(src => src.hasPermission(4))
            .then(Commands.argument("enabled", Arguments.STRING.create(event))
                .executes(ctx => {
                    var enabledStr = Arguments.STRING.getResult(ctx, "enabled");
                    global.friendlyFireEnabled = (enabledStr.toLowerCase() === "true");
                    console.info("[SYNC-FRIENDLY-FIRE] Friendly Fire set to: " + global.friendlyFireEnabled);
                    return 1;
                })
            )
    );

    // Command: /sync-pvp <true/false> (RCON/Console Only)
    event.register(
        Commands.literal("sync-pvp")
            .requires(src => src.hasPermission(4))
            .then(Commands.argument("enabled", Arguments.STRING.create(event))
                .executes(ctx => {
                    var enabledStr = Arguments.STRING.getResult(ctx, "enabled");
                    global.pvpEnabled = (enabledStr.toLowerCase() === "true");
                    console.info("[SYNC-PVP] PvP set to: " + global.pvpEnabled);
                    return 1;
                })
            )
    );
});

// Friendly Fire Protection & Global PvP Control
EntityEvents.hurt(event => {
    var source = event.source;
    var entity = event.entity;
    if (!source || !entity) return;

    if (entity.isPlayer() && source.actualEntity && source.actualEntity.isPlayer()) {
        var player = entity;
        var attacker = source.actualEntity;

        // 1. Global PvP Control
        if (!global.pvpEnabled) {
            event.cancel();
            attacker.tell(Text.red("§c[Servidor] El PvP está deshabilitado en este momento."));
            return;
        }

        // 2. Team Friendly Fire Protection
        var playerTeam = player.persistentData.getInt('teamId') || 0;
        var attackerTeam = attacker.persistentData.getInt('teamId') || 0;

        if (playerTeam > 0 && attackerTeam > 0 && playerTeam === attackerTeam) {
            if (!global.friendlyFireEnabled) {
                event.cancel();
                attacker.tell(Text.red("§c[Equipo] No puedes dañar a tus compañeros de equipo."));
            }
        }
    }
});
