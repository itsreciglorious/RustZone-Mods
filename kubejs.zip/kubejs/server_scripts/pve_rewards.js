// priority: 0
console.info('Loaded pve_rewards.js');

EntityEvents.death(event => {
    var entity = event.entity;
    var source = event.source;
    if (!source || !entity) return;
    
    // Check if the dying entity is a player
    if (entity.isPlayer()) {
        console.info('[PLAYER-DEATH] ' + entity.username);
        
        // Try to find the killer player
        var killer = source.actualEntity || source.actual;
        if (!killer && source.immediateEntity) {
            killer = source.immediateEntity.owner || (typeof source.immediateEntity.getOwner === 'function' ? source.immediateEntity.getOwner() : null);
        }
        if (killer && typeof killer.isPlayer === 'function' && killer.isPlayer()) {
            console.info('[PLAYER-KILL] ' + killer.username + ' killed ' + entity.username);
            try {
                var server = entity.server;
                var deathMsg = '{"text":"§7[§c☠ PvP§7] §e' + killer.username + ' §fha eliminado a §c' + entity.username + ' §7[§c☠§7]"}';
                server.runCommandSilent("tellraw @a " + deathMsg);
                server.runCommandSilent("execute at " + entity.username + " run playsound minecraft:entity.skeleton_horse.death master @a ~ ~ ~ 10 1");
            } catch (e) {
                console.error("Error broadcasting PvP kill message: " + e);
            }
        }
    }
    
    // Try to find the attacker (player killer)
    var attacker = source.actualEntity || source.actual;
    if (!attacker && source.immediateEntity) {
        attacker = source.immediateEntity.owner || (typeof source.immediateEntity.getOwner === 'function' ? source.immediateEntity.getOwner() : null);
    }
    
    var typeStr = String(entity.type);
    
    // Debug logging for zombie deaths
    var isZombieType = typeStr.indexOf('zombie') !== -1 || typeStr.indexOf('husk') !== -1 || typeStr.indexOf('drowned') !== -1;
    if (isZombieType) {
        console.info('[DEBUG-PVE] Zombie ' + typeStr + ' died. source.actualEntity: ' + (source.actualEntity ? source.actualEntity.username || source.actualEntity.type : 'null') + ', source.actual: ' + (source.actual ? source.actual.username || source.actual.type : 'null') + ', source.immediateEntity: ' + (source.immediateEntity ? source.immediateEntity.type : 'null') + ', attacker resolved: ' + (attacker ? attacker.username || attacker.type : 'null') + ', isPlayer: ' + (attacker && typeof attacker.isPlayer === 'function' ? attacker.isPlayer() : 'no isPlayer method'));
    }
    
    if (attacker && typeof attacker.isPlayer === 'function' && attacker.isPlayer()) {
        var player = attacker;
        
        // Mapeo de mutantes y sus recompensas
        var MUTANT_REWARDS = {
            // Mod: Zombie Extreme
            'zombie_extreme:infected_juggernaut': 30,
            'zombie_extreme:rat_king': 50,
            'zombie_extreme:zero_patient': 100,
            'zombie_extreme:demolisher': 30,
            'zombie_extreme:night_hunter': 25,
            'zombie_extreme:assasin_black_ops': 20,
            'zombie_extreme:clicker': 15,
            'zombie_extreme:ram': 15,
            'zombie_extreme:devestated': 15,
            'zombie_extreme:divided': 15,
            'zombie_extreme:explosive_infected': 10,
            'zombie_extreme:goon': 15,
            'zombie_extreme:chainsaw': 20,
            'zombie_extreme:faceless': 15,
            'zombie_extreme:fetus': 10,
            'zombie_extreme:military': 10,
            'zombie_extreme:revived': 10,
            'zombie_extreme:infected_police': 10,
            'zombie_extreme:infected_hazmat': 10,
            'zombie_extreme:infected_military': 15,
            'zombie_extreme:boomer': 15,
            'zombie_extreme:inflated': 15,
            'zombie_extreme:parasite': 15,
            'zombie_extreme:infected': 10,
            'zombie_extreme:runner': 10,

            // Mod: Undead Revamp 2
            'undead_revamp2:theimmortal': 50,
            'undead_revamp2:theheavy': 25,
            'undead_revamp2:thedungeon': 30,
            'undead_revamp2:thebeartamer': 35,
            'undead_revamp2:thegliter': 20,
            'undead_revamp2:thepregnant': 25,
            'undead_revamp2:theordure': 25,
            'undead_revamp2:bigsucker': 15,
            'undead_revamp2:deadclogger': 15,
            'undead_revamp2:the_moonflower': 40,
            'undead_revamp2:thehunter': 20,
            'undead_revamp2:theposessive': 25,
            'undead_revamp2:therabidus': 20,
            'undead_revamp2:theskeeper': 20,
            'undead_revamp2:thesmoker': 20,
            'undead_revamp2:thespitter': 15,
            'undead_revamp2:theswarmer': 15,
            'undead_revamp2:bomber': 15,
            'undead_revamp2:thebidy': 20,
            'undead_revamp2:therod': 20,
            'undead_revamp2:clogger': 15,
            'undead_revamp2:thehorrors': 40,
            'undead_revamp2:thehorrorsdecoys': 20,
            'undead_revamp2:thewolf': 20,
            'undead_revamp2:slaveman': 15,
            'undead_revamp2:invisiclogger': 20,
            'undead_revamp2:invisiimmortal': 60,
            'undead_revamp2:invisiblebidy': 25,
            'undead_revamp2:neocrorines': 20,
            'undead_revamp2:sucker': 15,
            'undead_revamp2:thesomnolence': 30,
            'undead_revamp2:invisilehcery': 20,
            'undead_revamp2:lechery': 15,
            'undead_revamp2:thelurker': 20,

            // Mod: Apocalypse Now & Spore
            'apocalypsenow:hunter': 20,
            'spore:brute': 30,
            'spore:howitzer': 50,
            'spore:howler': 25,
            'spore:charger': 20,
            'spore:griefer': 25,
            'spore:gazen': 20,
            'spore:delusioner': 25,
            'spore:hindicator': 20,
            'spore:hindie': 20
        };
        
        var isZombie = false;
        var isMutant = false;
        var mutantReward = 0;
        
        if (MUTANT_REWARDS[typeStr] !== undefined) {
            isZombie = true;
            isMutant = true;
            mutantReward = MUTANT_REWARDS[typeStr];
        } else {
            // Verificar si es zombie común
            var commonPrefixes = [
                'minecraft:zombie', 'minecraft:husk', 'minecraft:drowned', 'minecraft:zombie_villager',
                'zombie_extreme:infected', 'zombie_extreme:crawler', 'zombie_extreme:runner',
                'undead_revamp2:clogger', 'undead_revamp2:sucker', 'undead_revamp2:bomber', 'undead_revamp2:slaveman', 'undead_revamp2:thewolf',
                'spore:inf_drowned', 'spore:scamper', 'spore:busser', 'spore:bloater'
            ];
            var isCommon = commonPrefixes.some(function(p) { return typeStr.indexOf(p) === 0; }) ||
                             typeStr.indexOf('apocalypsenow:walker_') === 0 || 
                             typeStr.indexOf('apocalypsenow:runner_') === 0 || 
                             typeStr.indexOf('apocalypsenow:crawler_') === 0 || 
                             typeStr === 'apocalypsenow:cannibal';
            if (isCommon) {
                isZombie = true;
            }
        }
        
        if (isZombie) {
            var totalKills = player.persistentData.getInt('totalZombieKills') || 0;
            var commonKills = player.persistentData.getInt('commonZombieKills') || 0;
            var mutantKills = player.persistentData.getInt('mutantZombieKills') || 0;
            var dailyKills = player.persistentData.getInt('dailyZombieKills') || 0;
            var dailyCompleted = player.persistentData.getBoolean('dailyMissionCompleted') || false;
            var lastDay = player.persistentData.getInt('lastMissionDay') || 0;
            
            var currentDay = Math.floor(player.level.day);
            if (currentDay !== lastDay) {
                dailyKills = 0;
                dailyCompleted = false;
                lastDay = currentDay;
                player.persistentData.putInt('lastMissionDay', lastDay);
                player.persistentData.putBoolean('dailyMissionCompleted', false);
                console.info('[DAILY-MISSION-RESET] ' + player.username + ' daily kills reset');
            }
            
            totalKills++;
            player.persistentData.putInt('totalZombieKills', totalKills);
            // Sincronizar el marcador en el sidebar nativo
            player.server.runCommandSilent("scoreboard players set " + player.username + " zombieKills " + totalKills);
            
            if (isMutant) {
                mutantKills++;
                player.persistentData.putInt('mutantZombieKills', mutantKills);
                
                // Emite logs para el backend
                console.info('[MUTANT-KILL] ' + player.username + ' killed ' + typeStr);
                console.info('[MUTANT-REWARD] ' + player.username + ' killed ' + typeStr + ' reward ' + mutantReward);
                
                // Alerta Tellraw
                player.tell(Text.of('§7[§6PvE§7] §a¡Has eliminado un Mutante! §e+$' + mutantReward + ' §fdepositados en tu tarjeta digital.'));
            } else {
                commonKills++;
                player.persistentData.putInt('commonZombieKills', commonKills);
                
                dailyKills++;
                player.persistentData.putInt('dailyZombieKills', dailyKills);
                
                console.info('[ZOMBIE-KILL] ' + player.username + ' killed ' + typeStr + ' count ' + commonKills);
                
                // Cada 50 zombies
                if (commonKills % 50 === 0) {
                    console.info('[ZOMBIE-REWARD] ' + player.username + ' reached ' + commonKills + ' reward 50');
                    player.tell(Text.of('§7[§6PvE§7] §a¡Objetivo de 50 zombies comunes cumplido! §e+$50 §fdepositados en tu tarjeta digital.'));
                }
                // Dynamic missions are now handled by the Node.js Backend directly
                // by intercepting the [ZOMBIE-KILL] and [MUTANT-KILL] logs.
            }
            
            // Comprobación de Ascenso
            var oldRank = getPveRank(totalKills - 1).name;
            var newRankObj = getPveRank(totalKills);
            if (oldRank !== newRankObj.name) {
                player.tell(Text.of('§7[§6Rango PvE§7] §a¡Felicitaciones! Has ascendido al rango §l' + newRankObj.name.toUpperCase() + '§a.'));
                updatePlayerTabName(player);
            }
        }
    }
});

PlayerEvents.loggedIn(event => {
    console.info('[PLAYER-JOIN] ' + event.player.username);
    // Sincronizar el marcador en el sidebar nativo al entrar
    var totalKills = event.player.persistentData.getInt('totalZombieKills') || 0;
    event.server.runCommandSilent("scoreboard players set " + event.player.username + " zombieKills " + totalKills);
});

PlayerEvents.loggedOut(event => {
    console.info('[PLAYER-LEAVE] ' + event.player.username);
});

var hasSyncedPlayers = false;
ServerEvents.tick(event => {
    var srv = event.server;
    if (!hasSyncedPlayers) {
        hasSyncedPlayers = true;
        srv.players.forEach(function(player) {
            console.info('[PLAYER-JOIN] ' + player.username);
        });
    }
});

ServerEvents.commandRegistry(event => {
    const { commands: Commands, arguments: Arguments } = event;
    event.register(
        Commands.literal("pve-reset")
            .requires(src => src.hasPermission(2))
            .executes(ctx => {
                const player = ctx.source.player;
                if (player) {
                    player.persistentData.putInt('totalZombieKills', 0);
                    player.persistentData.putInt('commonZombieKills', 0);
                    player.persistentData.putInt('mutantZombieKills', 0);
                    player.persistentData.putInt('dailyZombieKills', 0);
                    player.persistentData.putBoolean('dailyMissionCompleted', false);
                    console.info('[PVE-RESET] ' + player.username);
                    player.tell(Text.of("§7[§6PvE§7] §aTus estadísticas PvE han sido reiniciadas."));
                    updatePlayerTabName(player);
                }
                return 1;
            })
    );

    // Registrar /pve-career para cambiar rangos
    event.register(
        Commands.literal("pve-career")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .then(Commands.argument("rank", Arguments.STRING.create(event))
                    .executes(ctx => {
                        var username = Arguments.STRING.getResult(ctx, "player");
                        var rank = Arguments.STRING.getResult(ctx, "rank").toLowerCase();
                        var server = ctx.source.server;
                        
                        var targetPlayer = server.players.find(function(p) { 
                            return p.username.toLowerCase() === username.toLowerCase(); 
                        });
                        
                        if (!targetPlayer) {
                            ctx.source.sendFailure(Text.red("Jugador '" + username + "' no encontrado o está offline."));
                            return 0;
                        }
                        
                        const RANK_KILLS = {
                            'inmortal': 10000,
                            'leyenda': 5000,
                            'aniquilador': 2000,
                            'ejecutor': 1000,
                            'veterano': 500,
                            'exterminador': 250,
                            'cazador': 100,
                            'recluta': 0
                        };
                        
                        if (RANK_KILLS[rank] === undefined) {
                            ctx.source.sendFailure(Text.red("Rango inválido. Disponibles: recluta, cazador, exterminador, veterano, ejecutor, aniquilador, leyenda, inmortal"));
                            return 0;
                        }
                        
                        var newKills = RANK_KILLS[rank];
                        if (targetPlayer.username.toLowerCase() === 'enehtch' && rank === 'aniquilador') {
                            newKills = 4549;
                        }
                        targetPlayer.persistentData.putInt('totalZombieKills', newKills);
                        targetPlayer.persistentData.putInt('commonZombieKills', newKills);
                        
                        console.info('[PVE-SET-RANK] ' + targetPlayer.username + ' rank ' + rank + ' kills ' + newKills);
                        
                        ctx.source.sendSuccess(Text.green("Rango PvE de " + targetPlayer.username + " establecido a " + rank.toUpperCase() + " (" + newKills + " kills)."), true);
                        updatePlayerTabName(targetPlayer);
                        return 1;
                    })
                )
            )
    );

    // Registrar /top-pve para todos los jugadores
    event.register(
        Commands.literal("top-pve")
            .executes(ctx => {
                var player = ctx.source.player;
                var username = player ? player.username : "console";
                console.info('[TOP-PVE-REQ] ' + username);
                return 1;
            })
    );

    // Registrar /setrank para asignar rangos web (VIP, Fundador, etc)
    event.register(
        Commands.literal("setrank")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .then(Commands.argument("rank", Arguments.STRING.create(event))
                    .executes(ctx => {
                        var username = Arguments.STRING.getResult(ctx, "player");
                        var rank = Arguments.STRING.getResult(ctx, "rank").toLowerCase();
                        
                        const validRanks = ['sobreviviente', 'contribuidor', 'contribuidor+', 'contribuidor++', 'fundador', 'clear'];
                        if (validRanks.indexOf(rank) === -1) {
                            ctx.source.sendFailure(Text.red("Rango inválido. Disponibles: " + validRanks.join(', ')));
                            return 0;
                        }

                        // Emit log for backend to process
                        console.info('[SET-WEB-RANK] ' + username + ' rank ' + rank);
                        ctx.source.sendSuccess(Text.green("Rango web de " + username + " modificado a: " + rank.toUpperCase()), true);
                        
                        // Update in-game Tab List immediately if player is online
                        var server = ctx.source.server;
                        var targetPlayer = server.getPlayer(username);
                        if (targetPlayer) {
                            if (rank === 'clear') {
                                targetPlayer.persistentData.putString("customTabRank", "");
                            } else {
                                targetPlayer.persistentData.putString("customTabRank", rank);
                            }
                            // Call updatePlayerTabName directly if available in global scope, 
                            // otherwise tablist.js 5-second tick will pick it up automatically.
                            if (typeof updatePlayerTabName === 'function') {
                                updatePlayerTabName(targetPlayer);
                            }
                        }
                        
                        return 1;
                    })
                )
            )
    );
});

ServerEvents.commandRegistry(event => {
    const { commands: Commands, arguments: Arguments } = event;
    event.register(
        Commands.literal("setpvekills")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .then(Commands.argument("kills", Arguments.INTEGER.create(event))
                    .then(Commands.argument("rank", Arguments.STRING.create(event))
                        .executes(ctx => {
                            var username = Arguments.STRING.getResult(ctx, "player");
                            var kills = Arguments.INTEGER.getResult(ctx, "kills");
                            var rank = Arguments.STRING.getResult(ctx, "rank");
                            var targetPlayer = ctx.source.server.players.find(function(p) { return p.username.toLowerCase() === username.toLowerCase(); });
                            if (targetPlayer) {
                                targetPlayer.persistentData.putInt('totalZombieKills', kills);
                                targetPlayer.persistentData.putInt('commonZombieKills', kills);
                                console.info('[PVE-SET-RANK] ' + targetPlayer.username + ' rank ' + rank + ' kills ' + kills);
                                ctx.source.sendSuccess(Text.green("Kills restored for " + username), true);
                            }
                            return 1;
                        })
                    )
                )
            )
    );
});
