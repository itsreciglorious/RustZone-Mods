// combat_tracker.js
// Rastrea cuándo un jugador entra en combate para restringir el uso de ciertos ítems

EntityEvents.hurt(event => {
    const entity = event.entity;
    const source = event.source.actual;
    
    const currentTime = new Date().getTime();
    
    // Si la entidad que recibe daño es un jugador, ponerlo en combate
    if (entity.isPlayer()) {
        entity.persistentData.putLong('lastCombatTime', currentTime);
        if (entity.persistentData.getLong('currentTpId') !== 0) {
            entity.persistentData.putLong('currentTpId', 0);
            entity.tell(Text.red('¡Teletransporte cancelado por entrar en combate!'));
            entity.playSound('minecraft:block.glass.break', 1.0, 1.0);
        }
    }
    
    // Si la entidad que causa el daño es un jugador, también ponerlo en combate
    if (source && source.isPlayer()) {
        source.persistentData.putLong('lastCombatTime', currentTime);
        if (source.persistentData.getLong('currentTpId') !== 0) {
            source.persistentData.putLong('currentTpId', 0);
            source.tell(Text.red('¡Teletransporte cancelado por entrar en combate!'));
            source.playSound('minecraft:block.glass.break', 1.0, 1.0);
        }
    }
});
