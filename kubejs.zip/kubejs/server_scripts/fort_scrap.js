// fort_scrap.js
// Sistema de Donación de Scrap para el Fuerte

let globalScrapAmount = 0; // Usado solo para no sobrecargar de logs si no hay cambios
let checkTicks = 0;

ServerEvents.tick(event => {
    let server = event.server;
    let level = server.getLevel('minecraft:overworld');

    // Repeler jugadores del pozo (Área: 7640 65 -2278 hasta 7642 67 -2276)
    // Usamos comandos vanilla para teletransportarlos lejos del centro
    server.runCommandSilent('execute as @a[x=7640,y=64,z=-2278,dx=2,dy=3,dz=2] at @s facing 7641.5 65 -2277.5 run tp @s ^ ^ ^-1.5');

    // Revisar ítems cada 10 ticks (0.5 segundos aprox) para no perder rendimiento
    checkTicks++;
    if (checkTicks < 10) return;
    checkTicks = 0;
    
    // Coordenadas del fondo del pozo donde se lanza el scrap
    // Área: 7640, 62, -2278 hasta 7642, 63, -2276
    let xMin = 7640;
    let xMax = 7642;
    let yMin = 62;
    let yMax = 63;
    let zMin = -2278;
    let zMax = -2276;

    // Buscar entidades en esa zona
    let aabb = AABB.of(xMin, yMin, zMin, xMax+1, yMax+1, zMax+1);
    let items = level.getEntitiesWithin(aabb);
    
    items.forEach(entity => {
        if (entity.type === 'minecraft:item') {
            let itemStack = entity.item;
            if (itemStack.id === 'rust_zone_official_mod:scrap' || 
                itemStack.id === 'rust_zone_official_mod:scrap_block' || 
                itemStack.id === 'rust_zone_official_mod:compressed_scrap_block') {
                
                let amount = itemStack.count;
                
                // Multiplicador por tipo de bloque
                if (itemStack.id === 'rust_zone_official_mod:scrap_block') {
                    amount *= 9;
                } else if (itemStack.id === 'rust_zone_official_mod:compressed_scrap_block') {
                    amount *= 81;
                }
                
                // Obtener UUID del jugador que lo tiró
                let throwerUUID = entity.nbt.Thrower;
                let throwerUUIDStr = 'unknown';
                
                if (throwerUUID && throwerUUID.length === 4) {
                    // Convertir el array de UUID a string (formato estandar 8-4-4-4-12)
                    let u1 = (throwerUUID[0] >>> 0).toString(16).padStart(8, '0');
                    let u2 = (throwerUUID[1] >>> 0).toString(16).padStart(8, '0');
                    let u3 = (throwerUUID[2] >>> 0).toString(16).padStart(8, '0');
                    let u4 = (throwerUUID[3] >>> 0).toString(16).padStart(8, '0');
                    
                    throwerUUIDStr = `${u1}-${u2.slice(0,4)}-${u2.slice(4,8)}-${u3.slice(0,4)}-${u3.slice(4,8)}${u4}`;
                }
                
                // Enviar Log para que el backend lo lea y guarde en la BD
                console.info(`[FORT_DONATION] ${throwerUUIDStr} ${amount}`);
                
                // Efectos visuales en el centro del pozo
                server.runCommandSilent(`execute in minecraft:overworld positioned 7641.5 66.5 -2277.5 run particle minecraft:totem_of_undying ~ ~ ~ 0.5 0.5 0.5 0.1 20 normal`);
                server.runCommandSilent(`execute in minecraft:overworld positioned 7641.5 66.5 -2277.5 run playsound minecraft:entity.player.levelup ambient @a ~ ~ ~ 1 1`);
                
                // Destruir el item
                entity.discard();
            }
        }
    });
});
