ServerEvents.commandRegistry(event => {
    const { commands: Commands, arguments: Arguments } = event;

    // Command: /saldo
    event.register(
        Commands.literal("saldo")
            .executes(ctx => {
                const player = ctx.source.player;
                if (player) {
                    console.log(`[ATM-KJS] ${player.username} issued command: /saldo`);
                    player.tell(Text.gray("[ATM] Procesando consulta de saldo..."));
                }
                return 1;
            })
    );

    // Command: /depositar <amount>
    event.register(
        Commands.literal("depositar")
            .then(Commands.argument('amount', Arguments.INTEGER.create(event))
                .executes(ctx => {
                    const player = ctx.source.player;
                    const amount = Arguments.INTEGER.getResult(ctx, 'amount');
                    if (player) {
                        console.log(`[ATM-KJS] ${player.username} issued command: /depositar ${amount}`);
                        player.tell(Text.gray(`[ATM] Procesando depósito de $${amount}...`));
                    }
                    return 1;
                })
            )
    );

    // Command: /retirar <amount>
    event.register(
        Commands.literal("retirar")
            .then(Commands.argument('amount', Arguments.INTEGER.create(event))
                .executes(ctx => {
                    const player = ctx.source.player;
                    const amount = Arguments.INTEGER.getResult(ctx, 'amount');
                    if (player) {
                        console.log(`[ATM-KJS] ${player.username} issued command: /retirar ${amount}`);
                        player.tell(Text.gray(`[ATM] Procesando retiro de $${amount}...`));
                    }
                    return 1;
                })
            )
    );
});
