// teleport_item.js
// Lógica para usar el cristal de teletransporte (Clic derecho)

ItemEvents.rightClicked('kubejs:teleport_crystal', event => {
    const player = event.player;
    
    // Obtener el tiempo de combate del jugador
    const lastCombatTime = player.persistentData.getLong('lastCombatTime') || 0;
    const currentTime = new Date().getTime();
    const combatDurationMs = 15000; // 15 segundos
    
    // Si han pasado menos de 15 segundos, está en combate
    if (currentTime - lastCombatTime < combatDurationMs) {
        const remainingTime = Math.ceil((combatDurationMs - (currentTime - lastCombatTime)) / 1000);
        player.tell(`§cNo puedes teletransportarte ahora. Estás en combate. (Espera ${remainingTime}s)`);
        event.cancel();
        return;
    }
    
    // Consumir un ítem de la mano
    if (!player.isCreative()) {
        event.item.count--;
    }
    
    // Mensaje y Teletransporte (usando el comando /spawn o un tp a coordenadas 0 100 0)
    // Asumimos que hay un comando /spawn configurado en el servidor o un plugin como FTB Essentials
    player.tell('§dTeletransportándote al spawn...');
    
    // Se añade un pequeño retraso visual si se desea, aquí lo hacemos instantáneo
    player.runCommandSilent('/spawn');
    
    // Efecto de sonido opcional (funciona si la ID del sonido es válida)
    player.runCommandSilent(`playsound minecraft:entity.enderman.teleport master ${player.username} ${player.x} ${player.y} ${player.z} 1.0 1.0`);
});
