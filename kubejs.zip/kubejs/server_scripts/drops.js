// ==========================================
// CONFIGURACIÓN DE SUMINISTROS (DROPS)
// ==========================================

const DROP_PREPARATION_TIME = 6000; 
const UNLOCK_COUNTDOWN_TIME = 30; 

const TIER_CONFIGS = {
    tier1: {
        source: "7636 41 -2254 7645 45 -2245", 
        chestOffsets: [{ x: 5, y: 1, z: 4 }, { x: 5, y: 1, z: 5 }], 
        dimensions: { w: 9, h: 4, d: 9 },
        lootTable: "rustzone:chests/tier1" 
    },
    tier2: {
        source: "7636 41 -2243 7645 46 -2234",
        chestOffsets: [{ x: 5, y: 2, z: 4 }, { x: 5, y: 2, z: 5 }],
        dimensions: { w: 9, h: 5, d: 9 },
        lootTable: "rustzone:chests/tier2"
    },
    tier3: {
        source: "7625 41 -2254 7634 46 -2245",
        chestOffsets: [{ x: 5, y: 3, z: 4 }, { x: 5, y: 3, z: 5 }],
        dimensions: { w: 9, h: 5, d: 9 },
        lootTable: "rustzone:chests/tier3"
    }
};

if (!global.activeDrops) global.activeDrops = [];
if (!global.pendingDrops) global.pendingDrops = [];
if (typeof global.adminExclusionActive === 'undefined') global.adminExclusionActive = true;

// Helper para programar la estructura
function scheduleDrop(tier, x, y, z, server, config) {
    server.runCommandSilent("forceload add " + x + " " + z + " " + (x + 10) + " " + (z + 10));
    server.runCommandSilent(`tellraw @a {"text":"§7[§6Suministros§7] §eSe ha detectado la caída de un suministro. En §a5 minutos §fse desvelará su posición. ¡Prepárense!"}`);

    const pendingDrop = {
        tier: tier, x: x, y: y, z: z, triggered: false, spawnFn: null
    };

    const spawnDropFn = () => {
        if (pendingDrop.triggered) return;
        pendingDrop.triggered = true;
        
        const srcCoords = config.source.split(' ');
        const srcMinX = srcCoords[0], srcMinZ = srcCoords[2], srcMaxX = srcCoords[3], srcMaxZ = srcCoords[5];

        server.runCommandSilent(`forceload add ${srcMinX} ${srcMinZ} ${srcMaxX} ${srcMaxZ}`);
        server.runCommandSilent(`clone ${config.source} ${x} ${y} ${z}`);
        server.runCommandSilent(`forceload remove ${srcMinX} ${srcMinZ} ${srcMaxX} ${srcMaxZ}`);

        const chest1X = x + config.chestOffsets[0].x, chest1Y = y + config.chestOffsets[0].y, chest1Z = z + config.chestOffsets[0].z;
        const chest2X = x + config.chestOffsets[1].x, chest2Y = y + config.chestOffsets[1].y, chest2Z = z + config.chestOffsets[1].z;

        server.runCommandSilent(`data merge block ${chest1X} ${chest1Y} ${chest1Z} {Lock: "locked_supply", LootTable: "${config.lootTable}"}`);
        server.runCommandSilent(`data merge block ${chest2X} ${chest2Y} ${chest2Z} {Lock: "locked_supply", LootTable: "${config.lootTable}"}`);

        const displayX = chest1X + 0.5, displayY = chest1Y + 1.5, displayZ = (chest1Z + chest2Z) / 2 + 0.5;
        const displayTag = `drop_${x}_${y}_${z}`;

        server.runCommandSilent("summon text_display " + displayX + " " + displayY + " " + displayZ + " {Tags: [\"drop_display\", \"" + displayTag + "\"], text: '{\"text\":\"§cEsperando sobrevivientes...\\\\n§7[Zona de Suministro]\",\"bold\":true}', billboard: \"center\"}");

        // Spawneo de Zombies
        let mobCount = tier === 'tier2' ? 8 : (tier === 'tier3' ? 12 : 0);
        if (mobCount > 0) {
            const helmet = tier === 'tier3' ? 'minecraft:iron_helmet' : 'minecraft:leather_helmet';
            for (let i = 0; i < mobCount; i++) {
                let mobType = Math.random() > 0.5 ? 'zombie' : 'husk';
                server.runCommandSilent(`summon ${mobType} ${displayX} ${y + 5} ${displayZ} {Tags:["drop_guard"], ArmorItems:[{},{},{},{id:"${helmet}",Count:1b}]}`);
            }
            // Esparcir alrededor de forma segura sobre la superficie
            server.runCommandSilent(`spreadplayers ${displayX} ${displayZ} 3 15 false @e[tag=drop_guard,distance=..20]`);
            server.runCommandSilent(`tag @e[tag=drop_guard] remove drop_guard`);
        }

        server.runCommandSilent(`tellraw @a {"text":"§7[§6Suministros§7] §e¡El suministro §f(§6${tier.toUpperCase()}§f)§e ha caído! §fCoordenadas: §aX: ${x}, Y: ${y}, Z: ${z}"}`);
        console.info(`[DROP-SPAWNED] ${tier} ${x} ${y} ${z}`);

        global.activeDrops.push({
            x: x, y: y, z: z,
            chest1X: chest1X, chest1Y: chest1Y, chest1Z: chest1Z,
            chest2X: chest2X, chest2Y: chest2Y, chest2Z: chest2Z,
            minX: x, minY: y, minZ: z,
            maxX: x + config.dimensions.w, maxY: y + config.dimensions.h, maxZ: z + config.dimensions.d,
            tier: tier, secondsRemaining: UNLOCK_COUNTDOWN_TIME, isCountingDown: false, tag: displayTag
        });

        const pIdx = global.pendingDrops.indexOf(pendingDrop);
        if (pIdx > -1) global.pendingDrops.splice(pIdx, 1);

        server.runCommandSilent("forceload remove " + x + " " + z + " " + (x + 10) + " " + (z + 10));
    };

    pendingDrop.spawnFn = spawnDropFn;
    global.pendingDrops.push(pendingDrop);

    server.scheduleInTicks(DROP_PREPARATION_TIME, () => spawnDropFn());
}

function initiateDynamicDrop(tier, server, sourceCtx, type) {
    var executor = sourceCtx && sourceCtx.source.player ? sourceCtx.source.player : null;
    
    // Helper para extraer coordenadas seguras de jugador (a prueba de balas)
    var getCoord = function(p, coord) {
        var v;
        if (coord === 'x') {
            try { v = Number(p.x); if (!isNaN(v)) return v; } catch(e) {}
            try { v = Number(p.getX()); if (!isNaN(v)) return v; } catch(e) {}
            try { v = Number(p.blockPosition().getX()); if (!isNaN(v)) return v; } catch(e) {}
            try { v = Number(p.blockPosition().x); if (!isNaN(v)) return v; } catch(e) {}
        } else if (coord === 'z') {
            try { v = Number(p.z); if (!isNaN(v)) return v; } catch(e) {}
            try { v = Number(p.getZ()); if (!isNaN(v)) return v; } catch(e) {}
            try { v = Number(p.blockPosition().getZ()); if (!isNaN(v)) return v; } catch(e) {}
            try { v = Number(p.blockPosition().z); if (!isNaN(v)) return v; } catch(e) {}
        }
        if (executor) executor.tell(Text.of(`[DEBUG ERROR] Imposible obtener coord ${coord}! Usando 0.`).red());
        return 0;
    };
    
    var players = [];
    try {
        server.players.forEach(p => {
            var isOver = false;
            try { isOver = p.level.isOverworld(); } catch(e) { isOver = String(p.level.dimension).includes('overworld'); }
            if (isOver) players.push(p);
        });
    } catch(err) {
        if (executor) executor.tell(Text.of(`[DEBUG ERROR] Error iterando jugadores: ${err}`).red());
        return;
    }

    if (players.length === 0) {
        if (executor) executor.tell(Text.of("No hay jugadores en el Overworld para calcular un Drop.").red());
        return;
    }
    
    var targetX = 0;
    var targetZ = 0;
    var level = players[0].level;
    
    if (players.length === 1) {
        var dist = Math.floor(Math.random() * 350) + 150;
        var pX = getCoord(players[0], 'x');
        var pZ = getCoord(players[0], 'z');
        targetX = Math.floor(pX + (Math.random() * (dist * 2) - dist));
        targetZ = Math.floor(pZ + (Math.random() * (dist * 2) - dist));
    } else {
        if (type === 'pvp') {
            var sumX = 0, sumZ = 0;
            players.forEach(p => { 
                sumX += getCoord(p, 'x'); 
                sumZ += getCoord(p, 'z'); 
            });
            targetX = Math.floor(sumX / players.length) + Math.floor(Math.random() * 100) - 50;
            targetZ = Math.floor(sumZ / players.length) + Math.floor(Math.random() * 100) - 50;
        } else {
            var rp = players[Math.floor(Math.random() * players.length)];
            var dist2 = Math.floor(Math.random() * 700) + 300;
            var pX2 = getCoord(rp, 'x');
            var pZ2 = getCoord(rp, 'z');
            targetX = Math.floor(pX2 + (Math.random() * (dist2 * 2) - dist2));
            targetZ = Math.floor(pZ2 + (Math.random() * (dist2 * 2) - dist2));
            level = rp.level;
        }
    }
    
    var attemptCount = 0;
    var maxAttempts = 15;
    
    var searchLocation = function(cx, cz) {
        attemptCount++;
        if (attemptCount > maxAttempts) {
            server.runCommandSilent(`tellraw ItsReciGlorious_ {"text":"§c[Drops] Se alcanzó el límite de intentos (15). Cancelando drop para evitar lag."}`);
            return;
        }

        server.runCommandSilent(`forceload add ${cx} ${cz} ${cx} ${cz}`);
        
        server.scheduleInTicks(20, () => {
            try {
                var finalY = 319;
                var foundSurface = false;
                
                // Buscar el bloque más alto que no sea aire ni hojas (para no quedar sobre los árboles)
                for (var y = 319; y > 0; y--) {
                    var block = level.getBlock(cx, y, cz);
                    if (block && block.id !== 'minecraft:air' && block.id !== 'minecraft:cave_air' && !block.id.includes('leaves') && !block.id.includes('log')) {
                        finalY = y + 1;
                        foundSurface = true;
                        break;
                    }
                }
                
                var dropDim = TIER_CONFIGS[tier].dimensions;
                var w = dropDim.w;
                var h = dropDim.h;
                var d = dropDim.d;
                
                var isClear = true;
                var failReason = "";
                var minFloorY = 999;
                var maxFloorY = -1;
                
                if (!foundSurface) {
                    isClear = false;
                    failReason = "No se encontró superficie sólida.";
                }
                
                // Verificar toda el área de colisión (x a x+w, z a z+d)
                for (var dx = 0; dx < w && isClear; dx++) {
                    for (var dz = 0; dz < d && isClear; dz++) {
                        var bx = cx + dx;
                        var bz = cz + dz;
                        
                        var columnFloor = -1;
                        // Comprobar desde la cima del drop hasta debajo del piso
                        for (var by = finalY + h; by >= finalY - 3; by--) {
                            var chkBlock = level.getBlock(bx, by, bz);
                            var id = chkBlock ? chkBlock.id : 'minecraft:air';
                            
                            var isObstacle = false;
                            // Ignorar aire, flores, pasto alto, nieve al evaluar obstáculos
                            if (id !== 'minecraft:air' && id !== 'minecraft:cave_air' && !id.includes('grass') && !id.includes('fern') && !id.includes('snow') && !id.includes('flower') && !id.includes('mushroom')) {
                                isObstacle = true;
                            }
                            
                            if (isObstacle) {
                                if (by >= finalY) {
                                    // Si hay un obstáculo a la altura del drop o más arriba, choca
                                    isClear = false;
                                    failReason = `Obstrucción en Y:${by} (${id})`;
                                    break;
                                } else {
                                    // Obstáculo DEBAJO de finalY se considera el "piso" de esta columna
                                    if (id.includes('water') || id.includes('lava') || id.includes('ice')) {
                                        isClear = false;
                                        failReason = `Agua, lava o hielo en el piso Y:${by}`;
                                        break;
                                    }
                                    if (columnFloor === -1) columnFloor = by;
                                }
                            }
                        }
                        
                        if (isClear && columnFloor !== -1) {
                            if (columnFloor < minFloorY) minFloorY = columnFloor;
                            if (columnFloor > maxFloorY) maxFloorY = columnFloor;
                        }
                    }
                }
                
                // Si la diferencia de alturas en el piso es mayor a 2, el terreno es muy irregular
                if (isClear && (maxFloorY - minFloorY > 2)) {
                    isClear = false;
                    failReason = `Terreno irregular (desnivel de ${maxFloorY - minFloorY} bloques)`;
                }
                
                server.runCommandSilent(`forceload remove ${cx} ${cz} ${cx} ${cz}`);
                
                if (isClear) {
                    server.runCommandSilent(`tellraw ItsReciGlorious_ {"text":"§a[Drops] Zona segura encontrada en X:${cx} Z:${cz} (Intento ${attemptCount})."}`);
                    scheduleDrop(tier, cx, finalY, cz, server, TIER_CONFIGS[tier]);
                } else {
                    server.runCommandSilent(`tellraw ItsReciGlorious_ {"text":"§e[Drops] Falló en X:${cx} Z:${cz}. Razón: ${failReason}. Buscando otra..."}`);
                    // Búsqueda saltando a otra zona (entre 20 y 60 bloques de distancia)
                    var offsetX = (Math.floor(Math.random() * 40) + 20) * (Math.random() > 0.5 ? 1 : -1);
                    var offsetZ = (Math.floor(Math.random() * 40) + 20) * (Math.random() > 0.5 ? 1 : -1);
                    searchLocation(cx + offsetX, cz + offsetZ);
                }
                
            } catch(err) {
                server.runCommandSilent(`forceload remove ${cx} ${cz} ${cx} ${cz}`);
                if (executor) executor.tell(Text.of(`[DEBUG ERROR TICK] ${err}`).red());
            }
        });
    };
    
    searchLocation(targetX, targetZ);
}

ServerEvents.commandRegistry(event => {
    const { commands: Commands, arguments: Arguments } = event;

    event.register(
        Commands.literal("drop")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("tier", Arguments.STRING.create(event))
                .then(Commands.argument("x", Arguments.INTEGER.create(event))
                    .then(Commands.argument("y", Arguments.INTEGER.create(event))
                        .then(Commands.argument("z", Arguments.INTEGER.create(event))
                            .executes(ctx => {
                                const tier = Arguments.STRING.getResult(ctx, "tier").toLowerCase();
                                const x = Arguments.INTEGER.getResult(ctx, "x"), y = Arguments.INTEGER.getResult(ctx, "y"), z = Arguments.INTEGER.getResult(ctx, "z");
                                if (!TIER_CONFIGS[tier]) return 0;
                                ctx.source.sendSuccess(Text.of(`Suministro manual (${tier}) programado en X:${x} Y:${y} Z:${z}`).green(), true);
                                scheduleDrop(tier, x, y, z, ctx.source.server, TIER_CONFIGS[tier]);
                                return 1;
                            })
                        )
                    )
                )
            )
    );

    event.register(
        Commands.literal("random-drop")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("tier", Arguments.STRING.create(event))
                .executes(ctx => {
                    try {
                        let selectedTier = Arguments.STRING.getResult(ctx, "tier").toLowerCase();
                        if (!TIER_CONFIGS[selectedTier]) {
                            return 0;
                        }
                        initiateDynamicDrop(selectedTier, ctx.source.server, ctx, 'random');
                        return 1;
                    } catch (e) {
                        return 0;
                    }
                })
            )
    );

    event.register(
        Commands.literal("pvp-drop")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("tier", Arguments.STRING.create(event))
                .executes(ctx => {
                    try {
                        let selectedTier = Arguments.STRING.getResult(ctx, "tier").toLowerCase();
                        if (!TIER_CONFIGS[selectedTier]) {
                            return 0;
                        }
                        initiateDynamicDrop(selectedTier, ctx.source.server, ctx, 'pvp');
                        return 1;
                    } catch (e) {
                        return 0;
                    }
                })
            )
    );
    
    // Comando puro de test para ver si la librería procesa comandos
    event.register(
        Commands.literal("test-drop")
            .requires(src => src.hasPermission(2))
            .executes(ctx => {
                return 1;
            })
    );

    event.register(
        Commands.literal("drop-tiempo-finalizar")
            .requires(src => src.hasPermission(2))
            .executes(ctx => {
                if (global.pendingDrops.length === 0) {
                    ctx.source.sendFailure(Text.of("No hay drops pendientes.").red());
                    return 0;
                }
                const dropToFinish = global.pendingDrops[global.pendingDrops.length - 1];
                ctx.source.sendSuccess(Text.of(`¡Acelerando caída en X:${dropToFinish.x} Z:${dropToFinish.z}!`).green(), true);
                dropToFinish.spawnFn();
                return 1;
            })
    );

    event.register(
        Commands.literal("drop-detect")
            .requires(src => src.hasPermission(2))
            .then(Commands.literal("on").executes(ctx => { global.adminExclusionActive = true; return 1; }))
            .then(Commands.literal("off").executes(ctx => { global.adminExclusionActive = false; return 1; }))
    );
    
    event.register(
        Commands.literal("drop-auto")
            .requires(src => src.hasPermission(2))
            .then(Commands.literal("on").executes(ctx => {
                let pd = ctx.source.server.persistentData;
                pd.autoDropsEnabled = true;
                pd.nextAutoDropTime = Date.now() + (Math.floor(Math.random() * 45) + 45) * 60000;
                ctx.source.sendSuccess(Text.of("Auto-Drops ACTIVADOS.").green(), true);
                return 1;
            }))
            .then(Commands.literal("off").executes(ctx => {
                ctx.source.server.persistentData.autoDropsEnabled = false;
                ctx.source.sendSuccess(Text.of("Auto-Drops DESACTIVADOS.").green(), true);
                return 1;
            }))
    );
});

ServerEvents.tick(event => {
    var srv = event.server;
    
    if (srv.tickCount % 100 === 0) {
        let pd = srv.persistentData;
        if (pd.autoDropsEnabled) {
            let now = Date.now();
            if (!pd.nextAutoDropTime || now >= pd.nextAutoDropTime) {
                let tier = Math.random() > 0.5 ? 'tier1' : 'tier2';
                console.info(`[AUTO-DROP] Triggering automatic random drop for ${tier}`);
                // Auto drops use "random" logic
                initiateDynamicDrop(tier, srv, null, 'random');
                
                let mins = Math.floor(Math.random() * 45) + 45;
                pd.nextAutoDropTime = now + (mins * 60000);
            }
        }
    }
    
    if (srv.tickCount % 20 === 0 && global.activeDrops.length > 0) {
        var onlinePlayers = [];
        srv.players.forEach(p => onlinePlayers.push(p));
        for (var index = global.activeDrops.length - 1; index >= 0; index--) {
            var drop = global.activeDrops[index];
            var playerNearby = null;
            
            for (var i = 0; i < onlinePlayers.length; i++) {
                var player = onlinePlayers[i];
                var u = player.username.toLowerCase();
                var isFounder = u === "itsreciglorious" || u === "itsreciglorious_" || u === "itsfreciglorious" || u === "itsfreciglorious_";
                if (global.adminExclusionActive && isFounder) continue;
                
                var dx = player.x - (drop.chest1X + drop.chest2X)/2;
                var dy = player.y - drop.chest1Y;
                var dz = player.z - (drop.chest1Z + drop.chest2Z)/2;
                
                if (Math.sqrt(dx*dx + dy*dy + dz*dz) <= 6.0) {
                    playerNearby = player;
                    break;
                }
            }
            
            if (drop.isCountingDown) {
                if (playerNearby) {
                    drop.secondsRemaining--;
                    if (drop.secondsRemaining > 0) {
                        var text = "§eDesbloqueando: §6" + drop.secondsRemaining + "s\\\\n§7[§b" + playerNearby.username + "§7]";
                        srv.runCommandSilent("data merge entity @e[tag=" + drop.tag + ",limit=1] {text: '{\"text\":\"" + text + "\"}'}");
                        srv.runCommandSilent("title " + playerNearby.username + " actionbar {\"text\":\"§e§l¡Mantente cerca! Desbloqueando: " + drop.secondsRemaining + "s\"}");
                    } else {
                        srv.runCommandSilent("data merge block " + drop.chest1X + " " + drop.chest1Y + " " + drop.chest1Z + " {Lock: \"\"}");
                        srv.runCommandSilent("data merge block " + drop.chest2X + " " + drop.chest2Y + " " + drop.chest2Z + " {Lock: \"\"}");
                        srv.runCommandSilent("data merge entity @e[tag=" + drop.tag + ",limit=1] {text: '{\"text\":\"§a¡Suministro Liberado!\",\"bold\":true}'}");
                        srv.runCommandSilent("tellraw @a {\"text\":\"§7[§6Suministros§7] §aEl suministro en §fX: " + drop.x + ", Y: " + drop.y + ", Z: " + drop.z + " §ahas sido desbloqueado por §e" + playerNearby.username + "§a!\"}");
                        
                        var tagToKill = drop.tag;
                        srv.scheduleInTicks(300, c => srv.runCommandSilent("kill @e[tag=" + tagToKill + "]"));
                        global.activeDrops.splice(index, 1);
                    }
                } else {
                    drop.isCountingDown = false;
                    drop.secondsRemaining = UNLOCK_COUNTDOWN_TIME;
                    srv.runCommandSilent("data merge entity @e[tag=" + drop.tag + ",limit=1] {text: '{\"text\":\"§cZona abandonada. Esperando sobrevivientes...\\\\n§7[Zona de Suministro]\",\"bold\":true}'}");
                }
            }
        }
    }
});

BlockEvents.broken(event => {
    var block = event.block;
    for (var i = 0; i < global.activeDrops.length; i++) {
        var drop = global.activeDrops[i];
        if (block.x >= drop.minX && block.x <= drop.maxX && block.y >= drop.minY && block.y <= drop.maxY && block.z >= drop.minZ && block.z <= drop.maxZ) {
            event.cancel();
            if (event.player) event.player.tell(Text.of("No puedes destruir la estructura del suministro hasta que sea liberado.").red());
            return;
        }
    }
});

BlockEvents.rightClicked(event => {
    var block = event.block;
    var player = event.player;
    
    
    
    for (var i = 0; i < global.activeDrops.length; i++) {
        var drop = global.activeDrops[i];
        
        

        if ((block.x === drop.chest1X && block.y === drop.chest1Y && block.z === drop.chest1Z) ||
            (block.x === drop.chest2X && block.y === drop.chest2Y && block.z === drop.chest2Z)) {
            
            var u = player.username.toLowerCase();
            var isFounder = u === "itsreciglorious" || u === "itsreciglorious_" || u === "itsfreciglorious" || u === "itsfreciglorious_";
            
            if (global.adminExclusionActive && isFounder) {
                player.tell(Text.of("Estás excluido de la activación. Usa /drop-detect off para poder interactuar.").red());
                event.cancel(); // Evita que se abra o salga el mensaje por defecto
                return;
            }
            
            if (!drop.isCountingDown) {
                drop.isCountingDown = true;
                player.tell(Text.of("¡Has iniciado la secuencia de desbloqueo! Mantente cerca por 30 segundos.").green());
                event.server.runCommandSilent("tellraw @a {\"text\":\"§7[§6Suministros§7] §e¡Un sobreviviente ha comenzado a desbloquear el suministro en §fX: " + drop.x + ", Y: " + drop.y + ", Z: " + drop.z + "§e!\"}");
            }
            
            // Cancelar el evento para evitar el mensaje vainilla "Chest is locked"
            // mientras se inicia el desbloqueo
            event.cancel();
            return;
        }
    }
});
