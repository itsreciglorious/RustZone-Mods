// ==========================================
// CONFIGURACIÓN DE SUMINISTROS (DROPS)
// ==========================================

// Tiempo de preparación en ticks (6000 ticks = 5 minutos)
// NOTA: Para realizar pruebas rápidas, puedes cambiar esto a 100 ticks (5 segundos).
const DROP_PREPARATION_TIME = 6000; 

// Tiempo de desbloqueo en segundos que el jugador debe mantener la zona
const UNLOCK_COUNTDOWN_TIME = 30; 

// Configuraciones de cada Tier de drop (Plantillas de construcción y cofres)
const TIER_CONFIGS = {
    tier1: {
        // Coordenadas de la estructura plantilla original a clonar: x1 y1 z1 x2 y2 z2
        source: "-4 -21 -4 4 -15 4", 
        // Coordenadas relativas donde estará el cofre dentro del área clonada (ej. x+2, y+1, z+2)
        chestOffset: { x: 4, y: 2, z: 4 }, 
        // Tabla de botín (Loot Table) para el cofre de Tier 1
        lootTable: "rustzone:chests/tier1" 
    },
    tier2: {
        source: "-14 -21 -4 -6 -15 4",
        chestOffset: { x: 4, y: 1, z: 4 },
        lootTable: "rustzone:chests/tier2"
    },
    tier3: {
        source: "-25 -21 -4 -16 -15 4",
        chestOffset: { x: 4, y: 2, z: 5 },
        lootTable: "rustzone:chests/tier3"
    }
};

// ==========================================
// LÓGICA INTERNA DEL SISTEMA
// ==========================================

let activeDrops = [];
let pendingDrops = [];
var adminExclusionActive = true;

ServerEvents.commandRegistry(event => {
    const { commands: Commands, arguments: Arguments } = event;

    // Registrar comando: /drop <tier> <x> <y> <z>
    event.register(
        Commands.literal("drop")
            .requires(src => src.hasPermission(2)) // Requiere nivel de OP (Admin)
            .then(Commands.argument("tier", Arguments.STRING.create(event))
                .then(Commands.argument("x", Arguments.INTEGER.create(event))
                    .then(Commands.argument("y", Arguments.INTEGER.create(event))
                        .then(Commands.argument("z", Arguments.INTEGER.create(event))
                            .executes(ctx => {
                                const tier = Arguments.STRING.getResult(ctx, "tier").toLowerCase();
                                const x = Arguments.INTEGER.getResult(ctx, "x");
                                const y = Arguments.INTEGER.getResult(ctx, "y");
                                const z = Arguments.INTEGER.getResult(ctx, "z");
                                
                                const server = ctx.source.server;
                                
                                if (tier !== "tier1" && tier !== "tier2" && tier !== "tier3") {
                                    ctx.source.sendFailure(Text.red(`Tier inválido "${tier}". Tiers disponibles: tier1, tier2, tier3`));
                                    return 0;
                                }

                                // 1. Cargar chunks del destino para asegurar el correcto clonado posterior
                                server.runCommandSilent("forceload add " + x + " " + z + " " + (x + 10) + " " + (z + 10));

                                // 2. Anuncio inicial público
                                server.runCommandSilent(`tellraw @a {"text":"§7[§6Suministros§7] §eSe ha detectado la caída de un suministro. En §a5 minutos §fse desvelará su posición. ¡Prepárense!"}`);
                                ctx.source.sendSuccess(Text.green(`Evento de suministro (${tier}) programado con éxito en X:${x} Y:${y} Z:${z}`), true);

                                // 2. Estructura de drop pendiente
                                const pendingDrop = {
                                    tier: tier,
                                    x: x,
                                    y: y,
                                    z: z,
                                    triggered: false,
                                    spawnFn: null
                                };

                                const spawnDropFn = () => {
                                    if (pendingDrop.triggered) return;
                                    pendingDrop.triggered = true;
                                    
                                    const config = TIER_CONFIGS[tier];
                                    
                                    // Clonar la estructura a las coordenadas destino
                                    server.runCommandSilent(`clone ${config.source} ${x} ${y} ${z}`);

                                    // Coordenadas absolutas del cofre
                                    const chestX = x + config.chestOffset.x;
                                    const chestY = y + config.chestOffset.y;
                                    const chestZ = z + config.chestOffset.z;

                                    // Bloquear el cofre e insertar la tabla de botín (LootTable)
                                    server.runCommandSilent(`data merge block ${chestX} ${chestY} ${chestZ} {Lock: "locked_supply", LootTable: "${config.lootTable}"}`);

                                    // Coordenadas del holograma (text_display)
                                    const displayX = chestX + 0.5;
                                    const displayY = chestY + 1.5;
                                    const displayZ = chestZ + 0.5;
                                    const displayTag = `drop_${x}_${y}_${z}`;

                                    // Crear holograma con text_display
                                    server.runCommandSilent("summon text_display " + displayX + " " + displayY + " " + displayZ + " {Tags: [\"drop_display\", \"" + displayTag + "\"], text: '{\"text\":\"§cEsperando sobrevivientes...\\\\n§7[Zona de Suministro]\",\"bold\":true}', billboard: \"center\"}");

                                    // Anuncio público con coordenadas reveladas
                                    server.runCommandSilent(`tellraw @a {"text":"§7[§6Suministros§7] §e¡El suministro §f(§6${tier.toUpperCase()}§f)§e ha caído! §fCoordenadas: §aX: ${x}, Y: ${y}, Z: ${z}"}`);

                                    // Registrar el drop en la lista activa de monitoreo
                                    activeDrops.push({
                                        x: x,
                                        y: y,
                                        z: z,
                                        chestX: chestX,
                                        chestY: chestY,
                                        chestZ: chestZ,
                                        tier: tier,
                                        secondsRemaining: UNLOCK_COUNTDOWN_TIME,
                                        isCountingDown: false,
                                        tag: displayTag
                                    });

                                    // Remover de la lista de pendientes
                                    const pIdx = pendingDrops.indexOf(pendingDrop);
                                    if (pIdx > -1) {
                                        pendingDrops.splice(pIdx, 1);
                                    }

                                    // Remover el forceload del destino para liberar recursos en memoria
                                    server.runCommandSilent("forceload remove " + x + " " + z + " " + (x + 10) + " " + (z + 10));
                                };

                                pendingDrop.spawnFn = spawnDropFn;
                                pendingDrops.push(pendingDrop);

                                // Programar caída después del tiempo de preparación
                                server.scheduleInTicks(DROP_PREPARATION_TIME, (callback) => {
                                    spawnDropFn();
                                });

                                return 1;
                            })
                        )
                    )
                )
            )
    );

    // Registrar comando: /drop-finalizar (para finalizar el tiempo del drop activo más reciente que aún no cae)
    const runFinalizeCmd = ctx => {
        if (pendingDrops.length === 0) {
            ctx.source.sendFailure(Text.red("No hay ningún suministro pendiente de caer (en cuenta de 5 minutos)."));
            return 0;
        }
        
        // Obtener el más reciente (el último que se programó)
        const dropToFinish = pendingDrops[pendingDrops.length - 1];
        ctx.source.sendSuccess(Text.green(`¡Acelerando caída del suministro ${dropToFinish.tier.toUpperCase()} en X:${dropToFinish.x} Y:${dropToFinish.y} Z:${dropToFinish.z}!`), true);
        
        dropToFinish.spawnFn();
        return 1;
    };

    event.register(
        Commands.literal("drop-finalizar")
            .requires(src => src.hasPermission(2))
            .executes(runFinalizeCmd)
    );

    event.register(
        Commands.literal("drop-tiempo-finalizar")
            .requires(src => src.hasPermission(2))
            .executes(runFinalizeCmd)
    );

    // Registrar comando: /drop-detect <on|off>
    event.register(
        Commands.literal("drop-detect")
            .requires(src => src.hasPermission(2)) // Requiere OP
            .then(Commands.argument("state", Arguments.STRING.create(event))
                .executes(ctx => {
                    var state = Arguments.STRING.getResult(ctx, "state").toLowerCase();
                    if (state === "on" || state === "true") {
                        adminExclusionActive = true;
                        ctx.source.sendSuccess(Text.green("Exclusión de administrador ACTIVADA. Los admins no activarán los suministros."), true);
                    } else if (state === "off" || state === "false") {
                        adminExclusionActive = false;
                        ctx.source.sendSuccess(Text.green("Exclusión de administrador DESACTIVADA. Los admins SÍ activarán los suministros."), true);
                    } else {
                        ctx.source.sendFailure(Text.red("Uso correcto: /drop-detect <on|off>"));
                    }
                    return 1;
                })
            )
    );
});

// Monitoreo de drops en el evento de Tick del servidor (se ejecuta cada segundo)
ServerEvents.tick(event => {
    var srv = event.server;
    if (srv.tickCount % 20 === 0) {
        if (activeDrops.length > 0) {
            var onlinePlayers = srv.players;
            
            for (var index = activeDrops.length - 1; index >= 0; index--) {
                var drop = activeDrops[index];
                var playerNearby = null;
                
                // Buscar jugador más cercano en el radio de 6 bloques
                for (var i = 0; i < onlinePlayers.length; i++) {
                    var player = onlinePlayers[i];
                    // Excluir al administrador ItsReciGlorious_ si la exclusión está activa
                    if (adminExclusionActive && (player.username === "ItsReciGlorious_" || player.username === "ItsFreciGlorious_")) continue;
                    
                    var dx = player.x - drop.chestX;
                    var dy = player.y - drop.chestY;
                    var dz = player.z - drop.chestZ;
                    var dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
                    
                    if (dist <= 6.0) {
                        playerNearby = player;
                        break;
                    }
                }
                
                if (playerNearby) {
                    drop.isCountingDown = true;
                    drop.secondsRemaining--;
                    
                    if (drop.secondsRemaining > 0) {
                        // Actualizar holograma de cuenta regresiva
                        var text = "§eDesbloqueando: §6" + drop.secondsRemaining + "s\\\\n§7[§b" + playerNearby.username + "§7]";
                        srv.runCommandSilent("data merge entity @e[tag=" + drop.tag + ",limit=1] {text: '{\"text\":\"" + text + "\"}'}");
                        
                        // Mandar alerta constante a la barra del jugador cercano
                        srv.runCommandSilent("title " + playerNearby.username + " actionbar {\"text\":\"§e§l¡Mantente cerca! Desbloqueando: " + drop.secondsRemaining + "s\"}");
                    } else {
                        // Desbloquear cofre (limpiar etiqueta Lock)
                        srv.runCommandSilent("data merge block " + drop.chestX + " " + drop.chestY + " " + drop.chestZ + " {Lock: \"\"}");
                        
                        // Cambiar holograma a liberado
                        srv.runCommandSilent("data merge entity @e[tag=" + drop.tag + ",limit=1] {text: '{\"text\":\"§a¡Suministro Liberado!\",\"bold\":true}'}");
                        
                        // Anuncio global
                        srv.runCommandSilent("tellraw @a {\"text\":\"§7[§6Suministros§7] §aEl suministro en §fX: " + drop.x + ", Y: " + drop.y + ", Z: " + drop.z + " §ahas sido desbloqueado por §e" + playerNearby.username + "§a!\"}");
                        
                        // Programar eliminación del holograma en 15 segundos (300 ticks)
                        var tagToKill = drop.tag;
                        srv.scheduleInTicks(300, c => {
                            srv.runCommandSilent("kill @e[tag=" + tagToKill + "]");
                        });
                        
                        // Remover de la lista de drops activos
                        activeDrops.splice(index, 1);
                    }
                } else {
                    // Si no hay jugadores cerca y estaba contando, reiniciar cuenta regresiva
                    if (drop.isCountingDown) {
                        drop.isCountingDown = false;
                        drop.secondsRemaining = UNLOCK_COUNTDOWN_TIME;
                        
                        srv.runCommandSilent("data merge entity @e[tag=" + drop.tag + ",limit=1] {text: '{\"text\":\"§cZona abandonada. Esperando sobrevivientes...\\\\n§7[Zona de Suministro]\",\"bold\":true}'}");
                    }
                }
            }
        }
    }
});

// Prevenir que los jugadores destruyan cofres de suministros activos mientras estén bloqueados
BlockEvents.broken(event => {
    var block = event.block;
    if (block.id === 'minecraft:chest') {
        for (var i = 0; i < activeDrops.length; i++) {
            var drop = activeDrops[i];
            if (block.x === drop.chestX && block.y === drop.chestY && block.z === drop.chestZ) {
                event.cancel();
                if (event.player) {
                    event.player.tell(Text.red("No puedes destruir el cofre de suministros mientras esté bloqueado."));
                }
                return;
            }
        }
    }
});

// Activar el contador del suministro cuando un jugador hace clic derecho en el cofre
BlockEvents.rightClicked(event => {
    var block = event.block;
    var player = event.player;
    if (block.id === 'minecraft:chest') {
        for (var i = 0; i < activeDrops.length; i++) {
            var drop = activeDrops[i];
            if (block.x === drop.chestX && block.y === drop.chestY && block.z === drop.chestZ) {
                // Excluir al administrador si la exclusión está activa
                if (adminExclusionActive && (player.username === "ItsReciGlorious_" || player.username === "ItsFreciGlorious_")) {
                    player.tell(Text.red("Estás excluido de la activación de suministros. Usa '/drop-detect off' para poder activarlo."));
                    return;
                }
                
                // Si el drop no está contando, iniciar la secuencia
                if (!drop.isCountingDown) {
                    drop.isCountingDown = true;
                    player.tell(Text.green("¡Has iniciado la secuencia de desbloqueo! Mantente cerca por 30 segundos."));
                    event.server.runCommandSilent("tellraw @a {\"text\":\"§7[§6Suministros§7] §e¡Un sobreviviente ha comenzado a desbloquear el suministro en §fX: " + drop.x + ", Y: " + drop.y + ", Z: " + drop.z + "§e!\"}");
                }
            }
        }
    }
});

