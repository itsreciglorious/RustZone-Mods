// Global variable to control PvP
global.pvpEnabled = false; // Default is false (PvP disabled)



ServerEvents.commandRegistry(event => {
    const { commands: Commands, arguments: Arguments } = event;
    
    event.register(
        Commands.literal("server-pvp")
            .requires(src => src.hasPermission(2)) // Require level 2 OP
            .executes(ctx => {
                const status = global.pvpEnabled ? "§aActivado" : "§cDesactivado";
                ctx.source.sendSuccess(Text.of(`§7[§6Servidor§7] §fEl PvP está actualmente: ${status}`), false);
                return 1;
            })
            .then(Commands.argument("active", Arguments.BOOLEAN.create(event))
                .executes(ctx => {
                    const active = Arguments.BOOLEAN.getResult(ctx, "active");
                    global.pvpEnabled = active;
                    
                    const statusText = active ? "§a¡El PvP ha sido activado globalmente!" : "§c¡El PvP ha sido desactivado globalmente!";
                    ctx.source.server.runCommandSilent(`tellraw @a {"text":"§7[§6Servidor§7] ${statusText}"}`);
                    return 1;
                })
            )
    );

    event.register(
        Commands.literal("cabeza")
            .executes(ctx => {
                const player = ctx.source.player;
                if (player) {
                    console.log(`[ATM-KJS] ${player.username} issued command: /cabeza`);
                    player.tell(Text.gray("[Servidor] Buscando cabeza buscada activa..."));
                }
                return 1;
            })
    );

    event.register(
        Commands.literal("radar")
            .executes(ctx => {
                const player = ctx.source.player;
                if (player) {
                    console.log(`[ATM-KJS] ${player.username} issued command: /radar`);
                    player.tell(Text.gray("[Servidor] Buscando cabeza buscada activa..."));
                }
                return 1;
            })
    );

    event.register(
        Commands.literal("ruleta-force")
            .requires(src => src.hasPermission(2))
            .executes(ctx => {
                const player = ctx.source.player;
                if (player) {
                    console.log(`[ATM-KJS] ${player.username} issued command: /ruleta-force`);
                    player.tell(Text.gray("[Servidor] Forzando ronda de la ruleta de la muerte..."));
                }
                return 1;
            })
    );

    event.register(
        Commands.literal("cancelar-cabeza")
            .requires(src => src.hasPermission(2))
            .executes(ctx => {
                const player = ctx.source.player;
                if (player) {
                    console.log(`[ATM-KJS] ${player.username} issued command: /cancelar-cabeza`);
                    player.tell(Text.gray("[Servidor] Solicitando cancelación de cabeza buscada..."));
                }
                return 1;
            })
    );

    event.register(
        Commands.literal("skippvp")
            .requires(src => src.hasPermission(2))
            .executes(ctx => {
                const player = ctx.source.player;
                if (player) {
                    player.runCommandSilent(`tellraw ${player.username} ["",{"text":"¿Estás seguro de desactivar el PvP Global y la Ruleta de la muerte por el día de hoy?\\n","color":"yellow"},{"text":"[Sí]","color":"green","bold":true,"clickEvent":{"action":"run_command","value":"/skippvp-confirm"},"hoverEvent":{"action":"show_text","value":"Haz clic para desactivar"}},{"text":"  "},{"text":"[No]","color":"red","bold":true,"clickEvent":{"action":"run_command","value":"/skippvp-cancel"},"hoverEvent":{"action":"show_text","value":"Cancelar"}}]`);
                }
                return 1;
            })
    );

    event.register(
        Commands.literal("skippvp-confirm")
            .requires(src => src.hasPermission(2))
            .executes(ctx => {
                const player = ctx.source.player;
                if (player) {
                    console.log(`[ATM-KJS] ${player.username} issued command: /skippvp-confirm`);
                }
                return 1;
            })
    );

    event.register(
        Commands.literal("skippvp-cancel")
            .requires(src => src.hasPermission(2))
            .executes(ctx => {
                const player = ctx.source.player;
                if (player) {
                    player.tell(Text.of("§cOperación cancelada."));
                }
                return 1;
            })
    );

    event.register(
        Commands.literal("horde-reset")
            .requires(src => src.hasPermission(2))
            .executes(ctx => {
                const player = ctx.source.player;
                if (player) {
                    // Offset the playtime instead of attempting to overwrite a hardcoded stat
                    const currentPlaytime = player.nbt.playtime || 0;
                    player.persistentData.hordeOffset = currentPlaytime;
                    
                    // Resets the internal horde logic
                    ctx.source.server.runCommandSilent(`hordes reset ${player.username}`);
                    
                    player.tell(Text.of("§a[Hordas] Se ha reiniciado tu contador de supervivencia a 0."));
                    console.log(`[ATM-KJS] ${player.username} reseteó su playtime de hordas.`);
                }
                return 1;
            })
    );
});
