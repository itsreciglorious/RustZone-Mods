ServerEvents.tick(event => {
    if (event.server.tickCount % 200 === 0) {
        console.info("TEST PLAYERS LENGTH: " + event.server.players.length);
        console.info("TEST PLAYERS SIZE: " + (typeof event.server.players.size === 'function' ? event.server.players.size() : 'no size func'));
    }
});
