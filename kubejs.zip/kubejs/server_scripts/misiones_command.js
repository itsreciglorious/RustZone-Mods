// priority: 0

ServerEvents.commandRegistry(event => {
    const { commands: Commands, arguments: Arguments } = event;

    // Command: /misiones
    event.register(
        Commands.literal("misiones")
            .executes(ctx => {
                const player = ctx.source.player;
                if (!player) return 0;

                player.tell(Text.of('§7[§6Misiones Diarias§7] §aConsultando tus misiones...'));
                console.info('[PVE-MISSION-LIST] ' + player.username);
                
                return 1;
            })
            // Subcommand: /misiones entregar
            .then(Commands.literal("entregar")
                .executes(ctx => {
                    const player = ctx.source.player;
                    if (!player) return 0;
                    
                    // The actual logic of handing over items is complex because we need to query the database.
                    // Instead, since the user said "Solo que el sistema detecte su obtención, no se los quites",
                    // and I didn't add an API to sync inventory to DB yet...
                    // Wait, if it's GATHER_ITEM, how does the backend know they got the item?
                    // I need KubeJS to tell the backend about the player's inventory!
                    
                    player.tell(Text.of('§7[§6Misiones Diarias§7] §aComprobando inventario...'));
                    
                    let items = [];
                    player.inventory.allItems.forEach(item => {
                        if (item && item.id !== 'minecraft:air') {
                            items.push({
                                id: String(item.id),
                                count: item.count
                            });
                        }
                    });
                    
                    // Emit a log that the backend can catch to process GATHER_ITEM missions!
                    console.info('[PVE-MISSION-SYNC] ' + player.username + ' ' + JSON.stringify(items));
                    
                    player.tell(Text.of('§7[§6Misiones Diarias§7] §aInventario sincronizado con el sistema de misiones.'));

                    return 1;
                })
            )
    );
});
