ServerEvents.recipes(event => {
    // Eliminar las recetas de crafteo de las Mochilas y Cofres del End para que solo se consigan mediante el vendedor
    event.remove({ output: 'enderchests:ender_pouch' });
    event.remove({ output: 'enderchests:ender_chest' });
});
