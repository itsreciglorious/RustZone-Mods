ItemEvents.rightClicked('kubejs:base_crystal', event => {
    try {
        var bc_player = event.player;
        var bc_item = event.item;
        var bc_level = event.level;
        
        if (bc_level.isClientSide()) return;
        
        // Validar tiempo en combate
        var bc_lastCombatTime = bc_player.persistentData.getLong('lastCombatTime') || 0;
        var bc_currentTime = new Date().getTime();
        var bc_combatDurationMs = 15000;
        
        if (bc_currentTime - bc_lastCombatTime < bc_combatDurationMs) {
            var bc_remainingTime = Math.ceil((bc_combatDurationMs - (bc_currentTime - bc_lastCombatTime)) / 1000);
            bc_player.tell(Text.red(`No puedes teletransportarte ahora. Estás en combate. (Espera ${bc_remainingTime}s)`));
            event.cancel();
            return;
        }
        
        // Revisar si ya tiene base guardada
        var bc_hasBase = bc_player.persistentData.getBoolean('hasBaseCrystalPos');
        
        if (!bc_hasBase) {
            // Establecer base (no gasta durabilidad)
            bc_player.persistentData.putBoolean('hasBaseCrystalPos', true);
            bc_player.persistentData.putDouble('baseX', bc_player.x);
            bc_player.persistentData.putDouble('baseY', bc_player.y);
            bc_player.persistentData.putDouble('baseZ', bc_player.z);
            bc_player.persistentData.putString('baseDim', bc_level.dimension.toString());
            
            bc_level.playSound(null, bc_player.x, bc_player.y, bc_player.z, 'minecraft:block.enchantment_table.use', 'players', 1.0, 1.0);
            bc_player.tell(Text.green('¡Punto de Retorno Personal establecido con éxito!'));
            bc_player.tell(Text.gray('A partir de ahora, usar este cristal te traerá a este bloque.'));
        } else {
            // Teletransportarse
            var bc_dimStr = bc_player.persistentData.getString('baseDim');
            var bc_bx = bc_player.persistentData.getDouble('baseX');
            var bc_by = bc_player.persistentData.getDouble('baseY');
            var bc_bz = bc_player.persistentData.getDouble('baseZ');
            
            bc_player.tell(Text.lightPurple('Teletransportándote a tu base en 20 segundos... ¡No entres en combate!'));
            
            var bc_tpId = new Date().getTime();
            bc_player.persistentData.putLong('currentTpId', bc_tpId);
            
            // Schedule ticks every second for 20 seconds
            [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19].forEach(i => {
                bc_level.server.scheduleInTicks(i * 20, callback => {
                    // Check if cancelled
                    if (bc_player.persistentData.getLong('currentTpId') !== bc_tpId) return;
                    
                    bc_player.setStatusMessage(Text.lightPurple(`Teletransporte en ${20 - i}s`));
                });
            });
            
            // Gastar durabilidad al iniciar el casteo
            if (!bc_player.isCreative()) {
                bc_item.setDamageValue(bc_item.getDamageValue() + 1);
                if (bc_item.getDamageValue() >= bc_item.getMaxDamage()) {
                    bc_item.count--;
                    bc_player.playSound('minecraft:entity.item.break');
                    bc_player.tell(Text.red('Tu Cristal de Base se ha roto por el uso.'));
                }
            }
            
            // Ejecutar TP a los 20 segundos (400 ticks)
            bc_level.server.scheduleInTicks(400, callback => {
                // Verificar que no haya sido cancelado
                if (bc_player.persistentData.getLong('currentTpId') !== bc_tpId) return;
                
                // Limpiar flag
                bc_player.persistentData.putLong('currentTpId', 0);
                
                bc_player.runCommandSilent(`execute in ${bc_dimStr} run tp ${bc_player.username} ${bc_bx} ${bc_by} ${bc_bz}`);
                bc_player.runCommandSilent(`playsound minecraft:entity.enderman.teleport master ${bc_player.username} ${bc_bx} ${bc_by} ${bc_bz} 1.0 1.0`);
                bc_player.setStatusMessage(Text.green('¡Teletransporte completado!'));
            });
        }
    } catch (e) {
        if (e.toString().includes('EventExit')) throw e;
        console.error('ERROR IN BASE CRYSTAL: ' + e);
        if (event && event.player) event.player.tell(Text.red('ERROR IN BASE CRYSTAL: ' + e));
    }
});
