// pvp_zone.js

const PVP_ZONES = [
    {
        name: "Ciudad PvP",
        minX: Math.min(8208, 8448),
        minY: Math.min(54, 152),
        minZ: Math.min(-1201, -1424),
        maxX: Math.max(8208, 8448),
        maxY: Math.max(54, 152),
        maxZ: Math.max(-1201, -1424)
    }
];

// (El horario global ahora es controlado exclusivamente por el backend y activa global.pvpEnabled)

function isInPvPZone(entity) {
    if (!entity) return false;
    let x = entity.x;
    let y = entity.y;
    let z = entity.z;
    for (let zone of PVP_ZONES) {
        if (x >= zone.minX && x <= zone.maxX &&
            y >= zone.minY && y <= zone.maxY &&
            z >= zone.minZ && z <= zone.maxZ) {
            return true;
        }
    }
    return false;
}

EntityEvents.hurt(event => {
    let victim = event.entity;
    let source = event.source;
    let attacker = source.actual; // Quien disparó o golpeó (jugador)

    // Solo revisamos si ambos son jugadores (PvP)
    if (victim.isPlayer() && attacker && attacker.isPlayer()) {
        // Si el PvP está forzado a encenderse en todo el mapa por un administrador, permitir daño
        if (global.pvpEnabled) {
            return;
        }

        let victimInPvP = isInPvPZone(victim);
        let attackerInPvP = isInPvPZone(attacker);

        // Si ambos están dentro de la zona PvP, ¡QUE LLUEVA SANGRE! (Permitido)
        if (victimInPvP && attackerInPvP) {
            return; 
        }

        // Lógica de "Barrera" (Alguien adentro dispara hacia afuera, o alguien afuera dispara hacia adentro)
        if (victimInPvP !== attackerInPvP) {
            event.cancel();
            attacker.tell("§c§l[!] §cNo puedes atacar cruzando la frontera de la Zona PvP.");
            return;
        }
        
        // Si ambos están AFUERA de la Zona PvP y el PvP Global no está activo
        // (Si estuviera activo global.pvpEnabled sería true y ya habría retornado arriba)
        if (!victimInPvP && !attackerInPvP) {
            event.cancel();
            attacker.tell("§e§l[!] §eEl PvP global está inactivo. Solo hay PvP en la Ciudad, o de 18:00 a 19:30.");
        }
    }
});

PlayerEvents.tick(event => {
    let player = event.player;
    
    // Ejecutar solo 1 vez por segundo (cada 20 ticks) para optimizar el servidor
    if (player.age % 20 !== 0) return;

    let currentlyInPvP = isInPvPZone(player);
    let wasInPvP = player.persistentData.getBoolean("wasInPvPZone");

    if (currentlyInPvP) {
        // Enviar mensaje al Actionbar usando comando nativo de Minecraft (fail-proof)
        player.runCommandSilent(`title ${player.username} actionbar {"text":"§c§l☠ ESTÁS EN ZONA PVP - TEN CUIDADO ☠"}`);
        
        if (!wasInPvP) {
            player.persistentData.putBoolean("wasInPvPZone", true);
        }
    } else {
        if (wasInPvP) {
            player.persistentData.putBoolean("wasInPvPZone", false);
            
            // Cuando sale de la zona, avisarle por el chat dependiendo del estado global
            if (!global.pvpEnabled) {
                player.tell("§a§l[!] §aHas salido de la Zona PvP. Ahora estás en territorio seguro.");
            } else {
                player.tell("§e§l[!] §eHas salido de la Ciudad, pero ten cuidado, el §cPvP Global §esigue activo (18:00 - 19:30).");
            }
        }
    }
});
