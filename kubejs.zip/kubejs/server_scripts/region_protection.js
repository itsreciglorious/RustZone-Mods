// region_protection.js

// Define aquí las zonas que quieres proteger
const PROTECTED_ZONES = [
    {
        name: "Punto Errante 1",
        minX: Math.min(8264, 8286),
        minY: Math.min(83, 93),
        minZ: Math.min(-1271, -1242),
        maxX: Math.max(8264, 8286),
        maxY: Math.max(83, 93),
        maxZ: Math.max(-1271, -1242)
    },
    {
        name: "Punto Errante 2",
        minX: Math.min(8397, 8368),
        minY: Math.min(71, 79),
        minZ: Math.min(-1383, -1361),
        maxX: Math.max(8397, 8368),
        maxY: Math.max(71, 79),
        maxZ: Math.max(-1383, -1361)
    },
    {
        name: "Punto Errante 3",
        minX: Math.min(8426, 8404),
        minY: Math.min(77, 84),
        minZ: Math.min(-1264, -1293),
        maxX: Math.max(8426, 8404),
        maxY: Math.max(77, 84),
        maxZ: Math.max(-1264, -1293)
    },
    {
        name: "Spawn",
        minX: Math.min(7583, 7680),
        minY: Math.min(96, -64),
        minZ: Math.min(-2289, -2192),
        maxX: Math.max(7583, 7680),
        maxY: Math.max(96, -64),
        maxZ: Math.max(-2289, -2192),
        antiPvP: true
    },
    {
        name: "Estructura Indestructible",
        minX: Math.min(7587, 7673),
        minY: Math.min(52, 67),
        minZ: Math.min(-2183, -2192),
        maxX: Math.max(7587, 7673),
        maxY: Math.max(52, 67),
        maxZ: Math.max(-2183, -2192)
    }
];

function getProtectedZone(x, y, z) {
    for (let zone of PROTECTED_ZONES) {
        if (x >= zone.minX && x <= zone.maxX &&
            y >= zone.minY && y <= zone.maxY &&
            z >= zone.minZ && z <= zone.maxZ) {
            return zone;
        }
    }
    return null;
}

function isProtected(x, y, z) {
    return getProtectedZone(x, y, z) !== null;
}

// Prevenir romper bloques
BlockEvents.broken(event => {
    if (event.player && event.player.isCreative()) return; // Los admins en creativo sí pueden
    
    let zone = getProtectedZone(event.block.x, event.block.y, event.block.z);
    if (zone) {
        event.cancel();
        if (event.player) {
            event.player.tell("§c§l[!] §cEsta zona está protegida: " + zone.name);
        }
    }
});

// Prevenir colocar bloques
BlockEvents.placed(event => {
    if (event.player && event.player.isCreative()) return;
    
    let zone = getProtectedZone(event.block.x, event.block.y, event.block.z);
    if (zone) {
        event.cancel();
        if (event.player) {
            event.player.tell("§c§l[!] §cNo puedes construir en la zona: " + zone.name);
        }
    }
});

// Prevenir PVP
EntityEvents.hurt(event => {
    let entity = event.getEntity();
    if (!entity || !entity.isPlayer()) return; // Solo protegemos jugadores contra jugadores
    
    let source = event.getSource().getActual();
    if (!source || !source.isPlayer()) return; // Si es daño de caída, zombie, etc., lo ignoramos (o podemos cancelarlo si queremos Modo Dios total)

    // Revisamos la víctima
    let victimZone = getProtectedZone(entity.x, entity.y, entity.z);
    if (victimZone && victimZone.antiPvP) {
        event.cancel();
        source.tell("§c§l[!] §cNo puedes atacar a jugadores dentro del " + victimZone.name);
        return;
    }
    
    // Revisamos al atacante
    let attackerZone = getProtectedZone(source.x, source.y, source.z);
    if (attackerZone && attackerZone.antiPvP) {
        event.cancel();
        source.tell("§c§l[!] §cNo puedes atacar desde dentro del " + attackerZone.name);
    }
});

// Prevenir explosiones dentro de la zona (si el evento de explosión está disponible en KubeJS)
// En versiones modernas de KubeJS Forge se usa LevelEvents.beforeExplosion
try {
    LevelEvents.beforeExplosion(event => {
        // Remover bloques afectados que estén dentro de la zona protegida
        let blocks = event.getAffectedBlocks();
        let it = blocks.iterator();
        while (it.hasNext()) {
            let blockPos = it.next();
            if (isProtected(blockPos.x, blockPos.y, blockPos.z)) {
                it.remove(); // Evita que la explosión destruya este bloque en específico
            }
        }
    });
} catch (e) {
    // Fallback silencioso por si el evento cambia de nombre en esta versión
}
