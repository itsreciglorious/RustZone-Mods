// black_market.js - Bridge to Node.js Backend
const StringArgumentType = Java.loadClass('com.mojang.brigadier.arguments.StringArgumentType');

ServerEvents.commandRegistry(event => {
    const { commands: Commands } = event;

    // Comando oculto ejecutado por el NPC (Role > Command: /blackmarket menu pico)
    event.register(
        Commands.literal('blackmarket')
            // .requires(src => src.hasPermission(2)) // Removed so NPC can execute it freely
            .then(Commands.literal('menu')
                .then(Commands.argument('tipo', StringArgumentType.word())
                    .executes(ctx => {
                        let player = ctx.source.player;
                        let tipo = StringArgumentType.getString(ctx, 'tipo');
                        console.info(`[BM-MENU] ${player.username} ${tipo}`);
                        return 1;
                    })
                )
            )
    );

    // Comando oculto ejecutado al hacer clic en el chat
    event.register(
        Commands.literal('bm_buy')
            // .requires(src => src.hasPermission(2)) // Removed so players can click chat commands
            .then(Commands.argument('id', StringArgumentType.word())
                .executes(ctx => {
                    let player = ctx.source.player;
                    let id = StringArgumentType.getString(ctx, 'id');
                    
                    // Check if player is near the NPC using a vanilla execute command
                    // This returns the number of custom NPCs within 6 blocks of the player
                    let count = player.server.runCommandSilent(`execute as ${player.username} at @s if entity @e[type=customnpcs:customnpc,distance=..6]`);

                    if (count === 0) {
                        player.tell(Text.of("§c¡Estás demasiado lejos! Acércate al Errante para poder comprar.").red());
                        return 0;
                    }

                    console.info(`[BM-BUY] ${player.username} ${id}`);
                    return 1;
                })
            )
    );
});
