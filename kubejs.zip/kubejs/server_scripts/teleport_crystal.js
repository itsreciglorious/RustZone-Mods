ItemEvents.rightClicked('kubejs:teleport_crystal', event => {
    const player = event.player;
    const item = event.item;
    const server = event.server;

    // Solo ejecutar en la mano principal para evitar que se lance dos veces
    if (event.hand !== 'MAIN_HAND') return;

    if (player.stages.has('teleporting')) {
        player.tell(Text.red('Ya estás canalizando el cristal.'));
        return;
    }
    if (player.stages.has('combat_cooldown')) {
        player.tell(Text.red('No puedes usar esto mientras estás en combate.'));
        return;
    }

    player.stages.add('teleporting');
    player.tell(Text.lightPurple('Canalizando energía... no recibas daño ni ataques durante 15 segundos.'));

    // Sonidos y partículas iniciales (Efecto Mágico)
    server.runCommandSilent(`execute at ${player.username} run playsound minecraft:block.amethyst_block.chime player @a ~ ~ ~ 1 1`);
    server.runCommandSilent(`execute at ${player.username} run playsound minecraft:block.portal.trigger player @a ~ ~ ~ 0.5 2`);
    server.runCommandSilent(`execute at ${player.username} run particle minecraft:reverse_portal ~ ~1 ~ 0.5 1 0.5 0.1 150`);

    // Sonido de "tick" cada segundo para no sentirse vacío
    for (let i = 1; i < 15; i++) {
        server.scheduleInTicks(i * 20, callback => {
            if (player.stages.has('teleporting') && player.isAlive()) {
                // Sonido sutil de "reloj" o "tick"
                server.runCommandSilent(`execute at ${player.username} run playsound minecraft:ui.button.click player @a ~ ~ ~ 0.8 1.5`);
            }
        });
    }

    // Esperamos 300 ticks (15 segundos)
    server.scheduleInTicks(300, callback => {
        // Si el estado fue removido, es porque se canceló
        if (!player.stages.has('teleporting')) return; 
        
        player.stages.remove('teleporting');

        if (!player.isAlive()) return;

        // Consumir 1 cristal
        item.count--;

        // Efecto antes de desaparecer
        server.runCommandSilent(`execute at ${player.username} run playsound minecraft:entity.enderman.teleport player @a ~ ~ ~ 1 1`);
        
        // Teletransporte
        server.runCommandSilent(`tp ${player.username} 7631 68 -2240`);
        
        // Efecto al aparecer en el spawn (Sonido de victoria/llegada)
        server.runCommandSilent(`execute at ${player.username} run playsound minecraft:entity.player.levelup player @a ~ ~ ~ 1 1`);
        server.runCommandSilent(`execute at ${player.username} run playsound minecraft:block.bell.use player @a ~ ~ ~ 1 1`);
        
        // Partículas chulas de llegada
        server.runCommandSilent(`execute at ${player.username} run particle minecraft:dragon_breath ~ ~1 ~ 0.5 1 0.5 0.1 150`);
        server.runCommandSilent(`execute at ${player.username} run particle minecraft:totem_of_undying ~ ~1 ~ 0.5 1 0.5 0.1 100`);
        
        player.tell(Text.green('¡Has regresado al campamento seguro!'));
    });
});

// Evento para cancelar el teletransporte en combate
EntityEvents.hurt(event => {
    const target = event.entity;
    const source = event.source.actual;
    
    // Si un jugador recibe daño
    if (target && target.isPlayer()) {
        if (target.stages.has('teleporting')) {
            target.stages.remove('teleporting');
            target.tell(Text.red('¡Teletransporte cancelado por recibir daño!'));
            event.server.runCommandSilent(`execute at ${target.username} run playsound minecraft:block.glass.break player @a ~ ~ ~ 1 1`);
        }
        target.stages.add('combat_cooldown');
        event.server.scheduleInTicks(200, callback => { // 10 segundos
            target.stages.remove('combat_cooldown');
        });
    }

    // Si un jugador ataca (hace daño)
    if (source && source.isPlayer()) {
        if (source.stages.has('teleporting')) {
            source.stages.remove('teleporting');
            source.tell(Text.red('¡Teletransporte cancelado por atacar!'));
            event.server.runCommandSilent(`execute at ${source.username} run playsound minecraft:block.glass.break player @a ~ ~ ~ 1 1`);
        }
        source.stages.add('combat_cooldown');
        event.server.scheduleInTicks(200, callback => { // 10 segundos
            source.stages.remove('combat_cooldown');
        });
    }
});
