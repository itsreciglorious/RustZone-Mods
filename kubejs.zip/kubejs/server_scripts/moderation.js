// priority: 0
console.info('Loaded moderation.js');

if (typeof global.spawnLockEnabled === 'undefined') {
    global.spawnLockEnabled = false;
}

function hasParticlePermission(player) {
    var u = player.username.toLowerCase();
    var isFounder = u === "itsreciglorious" || u === "itsreciglorious_" || u === "itsfreciglorious" || u === "itsfreciglorious_";
    if (isFounder || player.hasPermissions(2)) return true;
    try {
        var resolvedRank = player.persistentData.getString("customTabRank");
        if (resolvedRank) {
            resolvedRank = resolvedRank.toString().toLowerCase();
            if (resolvedRank === "contribuidor+" || resolvedRank === "contribuidor++" || resolvedRank === "fundador" || resolvedRank === "admin" || resolvedRank === "operador") {
                return true;
            }
        }
        
        var LuckPermsProvider = Java.loadClass('net.luckperms.api.LuckPermsProvider');
        var luckPerms = LuckPermsProvider.get();
        var uuid = player.getUuid ? player.getUuid() : (player.getUUID ? player.getUUID() : player.uuid);
        var user = luckPerms.getUserManager()["getUser(java.util.UUID)"](uuid);
        if (user) {
            // Check primary group
            var group = user.getPrimaryGroup();
            if (group) {
                var groupStr = group.toString().toLowerCase();
                if (groupStr === "contribuidor+" || groupStr === "contribuidor++" || groupStr === "fundador" || groupStr === "admin" || groupStr === "operador") {
                    return true;
                }
            }
            
            // Check prefix as fallback
            var prefix = user.getCachedData().getMetaData().getPrefix();
            if (prefix) {
                var prefixStr = prefix.toString();
                if (prefixStr.indexOf("💎+") > -1 || prefixStr.indexOf("💎++") > -1 || prefixStr.indexOf("👑") > -1) {
                    return true;
                }
            }
        }
    } catch (e) {
        console.error("Error checking particle permission: " + e);
    }
    return false;
}

PlayerEvents.chat(event => {
    var player = event.player;
    if (player) {
        if (player.persistentData.getBoolean('isMuted')) {
            var reason = player.persistentData.getString('muteReason') || "Ninguno";
            player.tell(Text.red("§cNo puedes hablar. Estás silenciado por un administrador. Motivo: " + reason));
            event.cancel();
            return;
        }

        // Color chat permission for contribuidor++ (Tier 3) or Founder
        var u = player.username.toLowerCase();
        var hasColorChat = u === "itsreciglorious" || u === "itsreciglorious_" || u === "itsfreciglorious" || u === "itsfreciglorious_";
        try {
            var resolvedRank = player.persistentData.getString("customTabRank");
            if (resolvedRank) {
                resolvedRank = resolvedRank.toString().toLowerCase();
                if (resolvedRank === "contribuidor++" || resolvedRank === "fundador") {
                    hasColorChat = true;
                }
            }
            
            if (!hasColorChat) {
                var LuckPermsProvider = Java.loadClass('net.luckperms.api.LuckPermsProvider');
                var luckPerms = LuckPermsProvider.get();
                var uuid = player.getUuid ? player.getUuid() : (player.getUUID ? player.getUUID() : player.uuid);
                var user = luckPerms.getUserManager()["getUser(java.util.UUID)"](uuid);
                if (user) {
                    // Check primary group
                    var group = user.getPrimaryGroup();
                    if (group) {
                        var groupStr = group.toString().toLowerCase();
                        if (groupStr === "contribuidor++" || groupStr === "fundador") {
                            hasColorChat = true;
                        }
                    }
                    
                    if (!hasColorChat) {
                        // Check prefix as fallback
                        var prefix = user.getCachedData().getMetaData().getPrefix();
                        if (prefix) {
                            var prefixStr = prefix.toString();
                            if (prefixStr.indexOf("💎++") > -1 || prefixStr.indexOf("👑") > -1) {
                                hasColorChat = true;
                            }
                        }
                    }
                }
            }
        } catch (e) {
            console.error("Error checking color chat permission for " + player.username + ": " + e);
        }

        if (hasColorChat) {
            var message = event.message;
            if (message && message.indexOf('&') > -1) {
                event.setMessage(message.replace(/&/g, '§'));
            }
        }
    }
});

let localTickCount = 0;

ServerEvents.tick(event => {
    var server = event.server;
    localTickCount++;
    try {
        var tickCount = localTickCount;
        var players = server.players;
        
        players.forEach(function(player) {
            if (!player) return;

            // Spawn-Lock logic
            if (global.spawnLockEnabled) {
                var u = player.username.toLowerCase();
                var isFounder = u === "itsreciglorious" || u === "itsreciglorious_" || u === "itsfreciglorious" || u === "itsfreciglorious_" || player.hasPermissions(2);
                if (!isFounder) {
                    var isCreativeOrSpectator = player.isCreative() || player.isSpectator() || player.gameMode == 'creative' || player.gameMode == 'spectator';
                    if (!isCreativeOrSpectator) {
                        var dx = player.x - 7632;
                        var dz = player.z - (-2240);
                        var distSq = dx * dx + dz * dz;
                        if (distSq > 1521) { // 39 * 39 = 1521
                            player.teleportTo(player.level.dimension, 7632, 71, -2240, player.yaw, player.pitch);
                            player.tell(Text.red("§cEl spawn está bloqueado temporalmente por un administrador. No puedes alejarte más de 39 bloques."));
                        }
                    }
                }
            }

            // Freeze logic
            if (player.persistentData.getBoolean('isFrozen')) {
                player.server.runCommandSilent("effect give " + player.username + " minecraft:slowness 2 255 true");
                player.server.runCommandSilent("effect give " + player.username + " minecraft:jump_boost 2 250 true");
                
                var fx = player.persistentData.getDouble('freezeX');
                var fy = player.persistentData.getDouble('freezeY');
                var fz = player.persistentData.getDouble('freezeZ');
                if (fx && fy && fz) {
                    var dist = Math.sqrt(Math.pow(player.x - fx, 2) + Math.pow(player.y - fy, 2) + Math.pow(player.z - fz, 2));
                    if (dist > 0.3) {
                        player.teleportTo(player.level.dimension, fx, fy, fz, player.yaw, player.pitch);
                    }
                }
            }

            // Spawn protection logic (X: 2578, Z: -458, radius: 40)
            var u = player.username.toLowerCase();
            var isProtectedExempt = u === "itsreciglorious" || u === "itsreciglorious_" || u === "itsfreciglorious" || u === "itsfreciglorious_" || player.hasPermissions(2);
            if (!isProtectedExempt) {
                var isCreativeOrSpectator = player.isCreative() || player.isSpectator() || player.gameMode == 'creative' || player.gameMode == 'spectator';
                if (!isCreativeOrSpectator) {
                    var dx = player.x - 7632;
                    var dz = player.z - (-2240);
                    var inSpawn = (dx * dx + dz * dz) <= 1600; // 40 * 40 = 1600
                    
                    var state = player.persistentData.getInt('spawnProtectedState');
                    if (state === 0) {
                        // First tick / login -> Initialize silently
                        player.persistentData.putInt('spawnProtectedState', inSpawn ? 1 : 2);
                        if (inSpawn) {
                            if (player.gameMode != 'adventure') {
                                player.server.runCommandSilent("gamemode adventure " + player.username);
                            }
                        } else {
                            if (player.gameMode != 'survival') {
                                player.server.runCommandSilent("gamemode survival " + player.username);
                            }
                        }
                    } else if (state === 1 && !inSpawn) {
                        // Just left spawn
                        player.persistentData.putInt('spawnProtectedState', 2);
                        if (player.gameMode != 'survival') {
                            player.server.runCommandSilent("gamemode survival " + player.username);
                        }
                        player.tell(Text.of("§6§l» §aHas salido de la zona protegida del Spawn. Modo Supervivencia activado. ¡Ten cuidado!").green());
                    } else if (state === 2 && inSpawn) {
                        // Just entered spawn
                        player.persistentData.putInt('spawnProtectedState', 1);
                        if (player.gameMode != 'adventure') {
                            player.server.runCommandSilent("gamemode adventure " + player.username);
                        }
                        player.tell(Text.of("§6§l» §eHas entrado a la zona protegida del Spawn. Modo Aventura activado.").yellow());
                    } else {
                        // Maintain/enforce current state in case gamemode is modified manually
                        if (inSpawn) {
                            if (player.gameMode != 'adventure') {
                                player.server.runCommandSilent("gamemode adventure " + player.username);
                            }
                        } else {
                            if (player.gameMode != 'survival') {
                                player.server.runCommandSilent("gamemode survival " + player.username);
                            }
                        }
                    }
                }
            }
        });

        // Mapa global de IDs a nombres de partículas
        var PARTICLE_MAP = {
            "fuego": "minecraft:flame",
            "corazones": "minecraft:heart",
            "portal": "minecraft:portal",
            "hojas": "minecraft:cherry_leaves",
            "estrellas": "minecraft:happy_villager",
            "end_rod": "minecraft:end_rod",
            "enchant": "minecraft:enchant",
            "nautilus": "minecraft:nautilus",
            "dragon_breath": "minecraft:dragon_breath",
            "totem": "minecraft:totem_of_undying",
            "witch": "minecraft:witch",
            "glow": "minecraft:glow",
            "spore": "minecraft:spore_blossom_air",
            "crimson_spore": "minecraft:crimson_spore",
            "warped_spore": "minecraft:warped_spore",
            "snowflake": "minecraft:snowflake",
            "ash": "minecraft:ash",
            "white_ash": "minecraft:white_ash",
            "smoke": "minecraft:campfire_cosy_smoke",
            "soul_fire": "minecraft:soul_fire_flame",
            "lava": "minecraft:lava",
            "soul": "minecraft:soul",
            "note": "minecraft:note",
            "damage": "minecraft:damage_indicator",
            "crit": "minecraft:crit",
            "enchanted_hit": "minecraft:enchanted_hit",
            "sonic_boom": "minecraft:sonic_boom",
            "sculk_charge": "minecraft:sculk_charge_pop",
            "sculk_soul": "minecraft:sculk_soul"
        };

        // Frecuencia: cada 2 ticks para que las espirales sean fluidas
        if (tickCount % 2 === 0) {
            players.forEach(function(player) {
                if (!player) return;

                var activeEffect = player.persistentData.getString("activeParticleEffect");
                if (activeEffect && activeEffect.toString() !== "" && activeEffect.toString() !== "desactivar") {
                    if (hasParticlePermission(player)) {
                        var pType = PARTICLE_MAP[activeEffect.toString()];
                        if (!pType) return;

                        var shape = player.persistentData.getString("activeParticleShape") || "aura";
                        shape = shape.toString();
                        var cmd = "";
                        var t = tickCount % 360;

                        if (tickCount % 60 === 0) {
                            console.info("[PARTICLE-TICK] Running " + pType + " shape " + shape + " for " + player.username);
                        }

                        if (shape === "espiral") {
                            // Espiral que sube y baja
                            var height = (t % 40) / 20.0; // Sube 0 a 2
                            if (height > 1.0) height = 2.0 - height; // Rebote 0 a 1 y baja a 0
                            height = height * 2.5; // Altura max 2.5
                            
                            var radius = 0.8;
                            var angle = t * 0.5; // Velocidad de giro
                            var cx = Math.cos(angle) * radius;
                            var cz = Math.sin(angle) * radius;
                            cmd = "execute at " + player.username + " run particle " + pType + " ~" + cx.toFixed(2) + " ~" + height.toFixed(2) + " ~" + cz.toFixed(2) + " 0 0 0 0 1 force";
                        } 

                        else if (shape === "halo") {
                            // Círculo arriba de la cabeza
                            var radius = 0.4;
                            var angle = t * 0.3;
                            var cx1 = Math.cos(angle) * radius;
                            var cz1 = Math.sin(angle) * radius;
                            var cx2 = Math.cos(angle + Math.PI) * radius; // Punto opuesto
                            var cz2 = Math.sin(angle + Math.PI) * radius;
                            
                            server.runCommandSilent("execute at " + player.username + " run particle " + pType + " ~" + cx1.toFixed(2) + " ~2.2 ~" + cz1.toFixed(2) + " 0 0 0 0 1 force");
                            server.runCommandSilent("execute at " + player.username + " run particle " + pType + " ~" + cx2.toFixed(2) + " ~2.2 ~" + cz2.toFixed(2) + " 0 0 0 0 1 force");
                        }
                        else {
                            // Aura / Pies default
                            var isMoving = Math.abs(player.motionX) > 0.05 || Math.abs(player.motionZ) > 0.05;
                            var dy = isMoving ? 0.2 : 1.0;
                            var yOff = isMoving ? 0.1 : 0.8;
                            var count = isMoving ? 3 : 2;
                            cmd = "execute at " + player.username + " run particle " + pType + " ~ ~" + yOff + " ~ 0.3 " + dy + " 0.3 0.01 " + count + " force";
                        }
                        
                        if (cmd !== "") {
                            if (tickCount % 60 === 0) {
                                console.info("[PARTICLE-DEBUG] " + cmd);
                            }
                            server.runCommandSilent(cmd);
                        }

                    } else {
                        player.persistentData.remove("activeParticleEffect");
                    }
                }
            });
        }
    } catch (e) {
        console.error("Error in ServerEvents.tick loop: " + e);
    }
});

ServerEvents.commandRegistry(event => {
    const { commands: Commands, arguments: Arguments } = event;

    // Command: /reparar
    event.register(
        Commands.literal("reparar")
            .requires(src => src.hasPermission(2))
            .executes(ctx => {
                let player = ctx.source.player;
                if (!player) return 0;
                let item = player.mainHandItem;
                if (!item || item.empty) {
                    player.tell(Text.red("No tienes nada en la mano para reparar."));
                    return 0;
                }
                if (item.maxDamage <= 0) {
                    player.tell(Text.red("Este objeto no se puede reparar."));
                    return 0;
                }
                item.damageValue = 0;
                player.tell(Text.green("¡Objeto reparado con éxito!"));
                return 1;
            })
    );

    // Command: /spawn-lock <on/off>
    event.register(
        Commands.literal("spawn-lock")
            .requires(src => src.hasPermission(2))
            .then(Commands.literal("on")
                .executes(ctx => {
                    global.spawnLockEnabled = true;
                    ctx.source.sendSuccess(Text.green("Spawn lock activado. Los jugadores no pueden alejarse más de 39 bloques del spawn."), true);
                    ctx.source.server.tell(Text.yellow("§7[§6Servidor§7] §cEl bloqueo del spawn ha sido ACTIVADO. Por favor, espera en el spawn a que comience la partida."));
                    return 1;
                })
            )
            .then(Commands.literal("off")
                .executes(ctx => {
                    global.spawnLockEnabled = false;
                    ctx.source.sendSuccess(Text.green("Spawn lock desactivado."), true);
                    ctx.source.server.tell(Text.yellow("§7[§6Servidor§7] §aEl bloqueo del spawn ha sido DESACTIVADO. ¡Ya puedes explorar el mundo!"));
                    return 1;
                })
            )
    );

    // Command: /warn <player> [reason]
    event.register(
        Commands.literal("warn")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .then(Commands.argument("reason", Arguments.GREEDY_STRING.create(event))
                    .executes(ctx => {
                        var username = Arguments.STRING.getResult(ctx, "player");
                        var reason = Arguments.GREEDY_STRING.getResult(ctx, "reason");
                        return runWarn(ctx, username, reason);
                    })
                )
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    return runWarn(ctx, username, "Incumplimiento de normas");
                })
            )
    );

    // Command: /mute <player> [reason]
    event.register(
        Commands.literal("mute")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .then(Commands.argument("reason", Arguments.GREEDY_STRING.create(event))
                    .executes(ctx => {
                        var username = Arguments.STRING.getResult(ctx, "player");
                        var reason = Arguments.GREEDY_STRING.getResult(ctx, "reason");
                        return runMute(ctx, username, reason);
                    })
                )
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    return runMute(ctx, username, "Comportamiento inadecuado");
                })
            )
    );

    // Command: /unmute <player>
    event.register(
        Commands.literal("unmute")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    var server = ctx.source.server;
                    var targetPlayer = server.players.find(function(p) {
                        return p.username.toLowerCase() === username.toLowerCase();
                    });
                    
                    // Even if the player is offline, we log it so backend can sync unmute
                    console.info("[UNMUTE-PLAYER] console unmuted " + username);
                    
                    if (targetPlayer) {
                        targetPlayer.persistentData.putBoolean('isMuted', false);
                        targetPlayer.persistentData.remove('muteReason');
                        targetPlayer.tell(Text.green("§aHas sido desmuteado. Ya puedes hablar en el chat."));
                        ctx.source.sendSuccess(Text.green("Jugador " + targetPlayer.username + " desmuteado."), true);
                    } else {
                        ctx.source.sendSuccess(Text.yellow("Jugador '" + username + "' está offline, desmuteado en registros."), true);
                    }
                    return 1;
                })
            )
    );

    // Command: /freeze <player>
    event.register(
        Commands.literal("freeze")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    var server = ctx.source.server;
                    var targetPlayer = server.players.find(function(p) {
                        return p.username.toLowerCase() === username.toLowerCase();
                    });
                    
                    if (!targetPlayer) {
                        ctx.source.sendFailure(Text.red("Jugador '" + username + "' no encontrado o está offline."));
                        return 0;
                    }
                    
                    targetPlayer.persistentData.putBoolean('isFrozen', true);
                    targetPlayer.persistentData.putDouble('freezeX', targetPlayer.x);
                    targetPlayer.persistentData.putDouble('freezeY', targetPlayer.y);
                    targetPlayer.persistentData.putDouble('freezeZ', targetPlayer.z);
                    
                    targetPlayer.tell(Text.red("§c§l¡HAS SIDO CONGELADO POR UN ADMINISTRADOR! NO INTENTES MOVERTE NI SALIR."));
                    console.info("[FREEZE-PLAYER] console froze " + targetPlayer.username);
                    ctx.source.sendSuccess(Text.green("Jugador " + targetPlayer.username + " congelado con éxito."), true);
                    return 1;
                })
            )
    );

    // Command: /unfreeze <player>
    event.register(
        Commands.literal("unfreeze")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    var server = ctx.source.server;
                    var targetPlayer = server.players.find(function(p) {
                        return p.username.toLowerCase() === username.toLowerCase();
                    });
                    
                    console.info("[UNFREEZE-PLAYER] console unfroze " + username);
                    
                    if (targetPlayer) {
                        targetPlayer.persistentData.putBoolean('isFrozen', false);
                        targetPlayer.persistentData.remove('freezeX');
                        targetPlayer.persistentData.remove('freezeY');
                        targetPlayer.persistentData.remove('freezeZ');
                        
                        // Clear effects
                        server.runCommandSilent("effect clear " + targetPlayer.username + " minecraft:slowness");
                        server.runCommandSilent("effect clear " + targetPlayer.username + " minecraft:jump_boost");
                        
                        targetPlayer.tell(Text.green("§aHas sido descongelado. Ya puedes moverte libremente."));
                        ctx.source.sendSuccess(Text.green("Jugador " + targetPlayer.username + " descongelado."), true);
                    } else {
                        ctx.source.sendSuccess(Text.yellow("Jugador '" + username + "' está offline, descongelado en registros."), true);
                    }
                    return 1;
                })
            )
    );

    // Command: /fly [player]
    event.register(
        Commands.literal("fly")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    var server = ctx.source.server;
                    var targetPlayer = server.players.find(function(p) {
                        return p.username.toLowerCase() === username.toLowerCase();
                    });
                    if (!targetPlayer) {
                        ctx.source.sendFailure(Text.red("Jugador '" + username + "' no encontrado."));
                        return 0;
                    }
                    toggleFly(targetPlayer, ctx.source);
                    return 1;
                })
            )
            .executes(ctx => {
                var player = ctx.source.player;
                if (!player) {
                    ctx.source.sendFailure(Text.red("Este comando requiere especificar un jugador desde la consola."));
                    return 0;
                }
                toggleFly(player, ctx.source);
                return 1;
            })
    );

    // Command: /god [player]
    event.register(
        Commands.literal("god")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    var server = ctx.source.server;
                    var targetPlayer = server.players.find(function(p) {
                        return p.username.toLowerCase() === username.toLowerCase();
                    });
                    if (!targetPlayer) {
                        ctx.source.sendFailure(Text.red("Jugador '" + username + "' no encontrado."));
                        return 0;
                    }
                    toggleGod(targetPlayer, ctx.source);
                    return 1;
                })
            )
            .executes(ctx => {
                var player = ctx.source.player;
                if (!player) {
                    ctx.source.sendFailure(Text.red("Este comando requiere especificar un jugador desde la consola."));
                    return 0;
                }
                toggleGod(player, ctx.source);
                return 1;
            })
    );

    // Command: /heal [player]
    event.register(
        Commands.literal("heal")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    var server = ctx.source.server;
                    var targetPlayer = server.players.find(function(p) {
                        return p.username.toLowerCase() === username.toLowerCase();
                    });
                    if (!targetPlayer) {
                        ctx.source.sendFailure(Text.red("Jugador '" + username + "' no encontrado."));
                        return 0;
                    }
                    healPlayer(targetPlayer, ctx.source);
                    return 1;
                })
            )
            .executes(ctx => {
                var player = ctx.source.player;
                if (!player) {
                    ctx.source.sendFailure(Text.red("Este comando requiere especificar un jugador desde la consola."));
                    return 0;
                }
                healPlayer(player, ctx.source);
                return 1;
            })
    );

    // Command: /feed [player]
    event.register(
        Commands.literal("feed")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    var server = ctx.source.server;
                    var targetPlayer = server.players.find(function(p) {
                        return p.username.toLowerCase() === username.toLowerCase();
                    });
                    if (!targetPlayer) {
                        ctx.source.sendFailure(Text.red("Jugador '" + username + "' no encontrado."));
                        return 0;
                    }
                    feedPlayer(targetPlayer, ctx.source);
                    return 1;
                })
            )
            .executes(ctx => {
                var player = ctx.source.player;
                if (!player) {
                    ctx.source.sendFailure(Text.red("Este comando requiere especificar un jugador desde la consola."));
                    return 0;
                }
                feedPlayer(player, ctx.source);
                return 1;
            })
    );

    // Command: /vista-rango <rango>
    event.register(
        Commands.literal("vista-rango")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("rango", Arguments.GREEDY_STRING.create(event))
                .executes(ctx => {
                    var rankStr = Arguments.GREEDY_STRING.getResult(ctx, "rango");
                    return runVistaRango(ctx, rankStr);
                })
            )
    );

    // Command: /rename <nombre>
    event.register(
        Commands.literal("rename")
            .then(Commands.argument("nombre", Arguments.GREEDY_STRING.create(event))
                .executes(ctx => {
                    var nameStr = Arguments.GREEDY_STRING.getResult(ctx, "nombre");
                    return runRename(ctx, nameStr);
                })
            )
    );

    // Command: /particulas
    event.register(
        Commands.literal("particulas")
            .then(Commands.literal("select")
                .then(Commands.argument("efecto", Arguments.STRING.create(event))
                    .executes(ctx => {
                        var effectStr = Arguments.STRING.getResult(ctx, "efecto");
                        return runSelectParticula(ctx, effectStr);
                    })
                )
            )
            .then(Commands.literal("shape")
                .then(Commands.argument("forma", Arguments.STRING.create(event))
                    .executes(ctx => {
                        var shapeStr = Arguments.STRING.getResult(ctx, "forma");
                        return runSelectShape(ctx, shapeStr);
                    })
                )
            )
            .then(Commands.literal("page")
                .then(Commands.argument("num", Arguments.INTEGER.create(event))
                    .executes(ctx => {
                        var num = Arguments.INTEGER.getResult(ctx, "num");
                        return runMenuParticulas(ctx, num);
                    })
                )
            )
            .executes(ctx => {
                return runMenuParticulas(ctx, 1);
            })
    );


    function runVistaRango(ctx, rankStr) {
        var player = ctx.source.player;
        if (!player) {
            ctx.source.sendFailure(Text.red("Este comando solo puede ser ejecutado por un jugador."));
            return 0;
        }

        // Check if player is ItsReciGlorious_ OR has LuckPerms group 'fundador'
        var u = player.username.toLowerCase();
        var isFounder = u === "itsreciglorious" || u === "itsreciglorious_" || u === "itsfreciglorious" || u === "itsfreciglorious_";
        if (!isFounder) {
            try {
                var LuckPermsProvider = Java.loadClass('net.luckperms.api.LuckPermsProvider');
                var luckPerms = LuckPermsProvider.get();
                var uuid = player.getUuid ? player.getUuid() : (player.getUUID ? player.getUUID() : player.uuid);
                var user = luckPerms.getUserManager()["getUser(java.util.UUID)"](uuid);
                if (user) {
                    var group = user.getPrimaryGroup();
                    if (group && group.toLowerCase() === "fundador") {
                        isFounder = true;
                    }
                }
            } catch (e) {
                console.error("Error checking LuckPerms group for " + player.username + ": " + e);
            }
        }

        if (!isFounder) {
            player.tell(Text.red("§cNo tienes permiso para ejecutar este comando. Solo los Fundadores pueden usar /vista-rango."));
            return 0;
        }

        var validRanks = ["sobreviviente", "contribuidor", "contribuidor+", "contribuidor++", "fundador", "clear"];
        var resolvedRank = rankStr.toLowerCase().trim();

        if (validRanks.indexOf(resolvedRank) === -1) {
            player.tell(Text.red("§cRango no válido. Rangos válidos: Sobreviviente, Contribuidor, Contribuidor+, Contribuidor++, Fundador (o 'clear' para restablecer)."));
            return 0;
        }

        if (resolvedRank === "clear") {
            // Remove persistent NBT tag
            player.persistentData.remove("customTabRank");
            
            // Print console info log for backend to sync actual group from LP
            console.info("[SET-VISTA-RANGO] " + player.username + " set visual rank clear");
            
            // Update immediately in-game
            updatePlayerTabName(player);
            
            player.tell(Text.green("§aTu rango visual ha sido restablecido a tu rango original."));
            return 1;
        }

        // Capitalize for DB and Tab
        var displayRank = resolvedRank;
        if (resolvedRank === "sobreviviente") displayRank = "Sobreviviente";
        else if (resolvedRank === "contribuidor") displayRank = "Contribuidor";
        else if (resolvedRank === "contribuidor+") displayRank = "Contribuidor+";
        else if (resolvedRank === "contribuidor++") displayRank = "Contribuidor++";
        else if (resolvedRank === "fundador") displayRank = "Fundador";

        // Store in persistent data for Tab list prefix override
        player.persistentData.putString("customTabRank", resolvedRank);

        // Print console info log for backend listener to catch and update DB
        console.info("[SET-VISTA-RANGO] " + player.username + " set visual rank " + displayRank);

        // Update player Tab List immediately
        updatePlayerTabName(player);

        player.tell(Text.green("§aTu rango visual para Tab y Frontend ha sido actualizado a: §l" + displayRank));
        return 1;
    }

    function runRename(ctx, nameStr) {
        var player = ctx.source.player;
        if (!player) {
            ctx.source.sendFailure(Text.red("Este comando solo puede ser ejecutado por un jugador."));
            return 0;
        }

        // Check if player is ItsReciGlorious_ OR has group 'fundador' OR 'contribuidor++'
        var u = player.username.toLowerCase();
        var hasPermission = u === "itsreciglorious" || u === "itsreciglorious_" || u === "itsfreciglorious" || u === "itsfreciglorious_";
        if (!hasPermission) {
            try {
                var resolvedRank = player.persistentData.getString("customTabRank");
                if (resolvedRank) {
                    resolvedRank = resolvedRank.toString().toLowerCase();
                } else {
                    resolvedRank = "";
                }
                
                if (!resolvedRank) {
                    var LuckPermsProvider = Java.loadClass('net.luckperms.api.LuckPermsProvider');
                    var luckPerms = LuckPermsProvider.get();
                    var uuid = player.getUuid ? player.getUuid() : (player.getUUID ? player.getUUID() : player.uuid);
                    var user = luckPerms.getUserManager()["getUser(java.util.UUID)"](uuid);
                    if (user) {
                        var prefix = user.getCachedData().getMetaData().getPrefix();
                        if (prefix) {
                            var prefixStr = prefix.toString();
                            if (prefixStr.indexOf("💎++") > -1 || prefixStr.indexOf("👑") > -1) {
                                hasPermission = true;
                            }
                        }
                    }
                } else if (resolvedRank === "contribuidor++" || resolvedRank === "fundador") {
                    hasPermission = true;
                }
            } catch (e) {
                console.error("Error checking LuckPerms group for " + player.username + ": " + e);
            }
        }

        if (!hasPermission) {
            player.tell(Text.red("§cNo tienes permiso para ejecutar este comando. Requiere rango Contribuidor++ o superior."));
            return 0;
        }

        var item = player.getMainHandItem();
        if (item.isEmpty()) {
            player.tell(Text.red("§cDebes sostener un objeto en tu mano principal para renombrarlo."));
            return 0;
        }

        // Convert Java String to JS String to properly use Regex replace
        var formattedName = String(nameStr).replace(/&/g, '§');

        // Set the custom name and explicitly disable the default Minecraft italic for renamed items
        item.setHoverName(Text.of(formattedName).italic(false));
        player.tell(Text.green("§a¡Objeto renombrado con éxito a: §r" + formattedName));
        return 1;
    }



    var ALL_PARTICLES = [
        { id: "fuego", name: "Fuego", icon: "🔥", color: "red", particle: "minecraft:flame" },
        { id: "corazones", name: "Corazones", icon: "💖", color: "lightPurple", particle: "minecraft:heart" },
        { id: "portal", name: "Portal", icon: "🔮", color: "darkPurple", particle: "minecraft:portal" },
        { id: "hojas", name: "Hojas", icon: "🌸", color: "lightPurple", particle: "minecraft:cherry_leaves" },
        { id: "estrellas", name: "Estrellas", icon: "⭐", color: "green", particle: "minecraft:happy_villager" },
        { id: "end_rod", name: "End Rod", icon: "🪄", color: "white", particle: "minecraft:end_rod" },
        { id: "enchant", name: "Encantamiento", icon: "✨", color: "blue", particle: "minecraft:enchant" },
        { id: "nautilus", name: "Nautilus", icon: "🐚", color: "aqua", particle: "minecraft:nautilus" },
        { id: "dragon_breath", name: "Dragón", icon: "🐉", color: "darkPurple", particle: "minecraft:dragon_breath" },
        { id: "totem", name: "Tótem", icon: "🗿", color: "yellow", particle: "minecraft:totem_of_undying" },
        { id: "witch", name: "Bruja", icon: "🧙", color: "darkPurple", particle: "minecraft:witch" },
        { id: "glow", name: "Brillo", icon: "🌟", color: "gold", particle: "minecraft:glow" },
        { id: "spore", name: "Esporas", icon: "🍄", color: "green", particle: "minecraft:spore_blossom_air" },
        { id: "crimson_spore", name: "Carmesí", icon: "🔴", color: "darkRed", particle: "minecraft:crimson_spore" },
        { id: "warped_spore", name: "Distorsionadas", icon: "🔵", color: "darkAqua", particle: "minecraft:warped_spore" },
        { id: "snowflake", name: "Nieve", icon: "❄️", color: "white", particle: "minecraft:snowflake" },
        { id: "ash", name: "Ceniza", icon: "🌋", color: "gray", particle: "minecraft:ash" },
        { id: "white_ash", name: "Cen. Blanca", icon: "☁️", color: "white", particle: "minecraft:white_ash" },
        { id: "smoke", name: "Humo", icon: "💨", color: "darkGray", particle: "minecraft:campfire_cosy_smoke" },
        { id: "soul_fire", name: "Fuego Alma", icon: "🔥", color: "aqua", particle: "minecraft:soul_fire_flame" },
        { id: "lava", name: "Lava", icon: "🌋", color: "gold", particle: "minecraft:lava" },
        { id: "soul", name: "Alma", icon: "👻", color: "aqua", particle: "minecraft:soul" },
        { id: "note", name: "Nota", icon: "🎵", color: "green", particle: "minecraft:note" },
        { id: "damage", name: "Daño", icon: "💔", color: "darkRed", particle: "minecraft:damage_indicator" },
        { id: "crit", name: "Crítico", icon: "⚔️", color: "gold", particle: "minecraft:crit" },
        { id: "enchanted_hit", name: "Golpe Mágico", icon: "🌟", color: "blue", particle: "minecraft:enchanted_hit" },
        { id: "sonic_boom", name: "Sónico", icon: "🔊", color: "darkAqua", particle: "minecraft:sonic_boom" },
        { id: "sculk_charge", name: "Sculk", icon: "⚡", color: "aqua", particle: "minecraft:sculk_charge_pop" },
        { id: "sculk_soul", name: "Alma Sculk", icon: "👻", color: "darkAqua", particle: "minecraft:sculk_soul" }
    ];

    function runMenuParticulas(ctx, page) {
        var player = ctx.source.player;
        if (!player) return 0;
        if (!hasParticlePermission(player)) {
            player.tell(Text.red("§cNo tienes el rango necesario para usar partículas. Requiere rango Contribuidor+ o superior."));
            return 0;
        }

        if (!page || page < 1) page = 1;
        var itemsPerPage = 6;
        var totalPages = Math.ceil(ALL_PARTICLES.length / itemsPerPage);
        if (page > totalPages) page = totalPages;

        var currentShape = player.persistentData.getString("activeParticleShape");
        if (!currentShape) currentShape = "aura";

        var shapeName = currentShape === "aura" ? "Aura/Pies" :
                        currentShape === "espiral" ? "Espiral" :
                        currentShape === "alas" ? "Alas" :
                        currentShape === "capa" ? "Capa" :
                        currentShape === "halo" ? "Halo" : currentShape;

        player.tell(Text.of(" "));
        player.tell(Text.of("§6§l★ Menú de Partículas Estéticas ★").gold());
        player.tell(Text.of("§7Elige un efecto para lucir en el servidor (Pág " + page + "/" + totalPages + "):").gray());

        // Forma toggle button
        player.tell(
            Text.of(" §b[Forma Actual: " + shapeName + "] ").aqua()
            .click('run_command:/particulas shape next')
            .hover("§eClic para cambiar la forma (Aura, Espiral, Alas, etc)")
        );
        player.tell(Text.of(" "));

        var startIndex = (page - 1) * itemsPerPage;
        var endIndex = Math.min(startIndex + itemsPerPage, ALL_PARTICLES.length);

        for (var i = startIndex; i < endIndex; i += 2) {
            var p1 = ALL_PARTICLES[i];
            var p2 = ALL_PARTICLES[i + 1];
            
            var line = Text.of(" §7- ").gray()
                .append(Text.of(p1.icon + " [" + p1.name + "] ")[p1.color]().click('run_command:/particulas select ' + p1.id).hover("§eActiva: " + p1.name));
            
            if (p2) {
                line.append(Text.of("   " + p2.icon + " [" + p2.name + "] ")[p2.color]().click('run_command:/particulas select ' + p2.id).hover("§eActiva: " + p2.name));
            }
            player.tell(line);
        }

        // Pagination buttons
        var pagination = Text.of(" ");
        if (page > 1) {
            pagination.append(Text.of("§c[⬅ Anterior] ").red().click('run_command:/particulas page ' + (page - 1)));
        }
        pagination.append(Text.of("  §8❌ [Desactivar] ").gray().click('run_command:/particulas select desactivar'));
        if (page < totalPages) {
            pagination.append(Text.of("  §a[Siguiente ➡]").green().click('run_command:/particulas page ' + (page + 1)));
        }
        player.tell(pagination);
        player.tell(Text.of(" "));
        return 1;
    }

    function runSelectParticula(ctx, effectStr) {
        var player = ctx.source.player;
        if (!player) return 0;
        if (!hasParticlePermission(player)) return 0;

        var effect = effectStr.toLowerCase().trim();

        if (effect === "desactivar") {
            player.persistentData.remove("activeParticleEffect");
            player.tell(Text.green("§aTus efectos de partículas estéticas han sido desactivados."));
            return 1;
        }

        var found = ALL_PARTICLES.find(function(p) { return p.id === effect; });
        if (!found) {
            player.tell(Text.red("§cEfecto no válido. Escribe /particulas para ver opciones."));
            return 0;
        }

        player.persistentData.putString("activeParticleEffect", found.id);
        player.tell(Text.green("§a¡Efecto establecido con éxito a: " + found.icon + " " + found.name));
        return 1;
    }

    function runSelectShape(ctx, shapeStr) {
        var player = ctx.source.player;
        if (!player) return 0;
        if (!hasParticlePermission(player)) return 0;

        var shapes = ["aura", "espiral", "halo"];
        var currentShape = player.persistentData.getString("activeParticleShape");
        if (!currentShape) currentShape = "aura";

        var newShape = "aura";
        if (shapeStr === "next") {
            var idx = shapes.indexOf(currentShape);
            newShape = shapes[(idx + 1) % shapes.length];
        } else if (shapes.indexOf(shapeStr) !== -1) {
            newShape = shapeStr;
        }

        player.persistentData.putString("activeParticleShape", newShape);
        player.tell(Text.aqua("§b¡Forma de partículas cambiada a: " + newShape.toUpperCase() + "!"));
        
        // Return to menu page 1 implicitly, or just keep them without re-opening menu to avoid spam,
        // but re-opening menu makes it easier to click again. Let's re-open menu.
        return runMenuParticulas(ctx, 1);
    }

    function runWarn(ctx, username, reason) {
        var server = ctx.source.server;
        var targetPlayer = server.players.find(function(p) {
            return p.username.toLowerCase() === username.toLowerCase();
        });
        
        if (!targetPlayer) {
            ctx.source.sendFailure(Text.red("Jugador '" + username + "' no encontrado o está offline."));
            return 0;
        }
        
        var warnings = (targetPlayer.persistentData.getInt('warnings') || 0) + 1;
        targetPlayer.persistentData.putInt('warnings', warnings);
        
        // Broadcast / Log
        console.info("[WARN-PLAYER] console warned " + targetPlayer.username + " count " + warnings + " reason: " + reason);
        
        // Notify target player with titles
        server.runCommandSilent("title " + targetPlayer.username + " title {\"text\":\"§c§l¡HAS SIDO ADVERTIDO!\",\"bold\":true}");
        server.runCommandSilent("title " + targetPlayer.username + " subtitle {\"text\":\"§eAdvertencia " + warnings + "/3. Motivo: " + reason + "\"}");
        targetPlayer.tell(Text.red("§c§l[ADVERTENCIA] §fHas sido advertido por un administrador. §cTotal: " + warnings + "/3§f. Motivo: §7" + reason));
        
        ctx.source.sendSuccess(Text.green("Jugador " + targetPlayer.username + " advertido (" + warnings + "/3)."), true);
        
        if (warnings >= 3) {
            targetPlayer.persistentData.putInt('warnings', 0);
            server.runCommandSilent("kick " + targetPlayer.username + " §cExpulsado del servidor por acumulación de 3 advertencias.");
            server.runCommandSilent("tellraw @a {\"text\":\"§7[§cModeración§7] §e" + targetPlayer.username + " §fha sido expulsado por acumulación de 3 advertencias.\"}");
        }
        return 1;
    }

    function runMute(ctx, username, reason) {
        var server = ctx.source.server;
        var targetPlayer = server.players.find(function(p) {
            return p.username.toLowerCase() === username.toLowerCase();
        });
        
        if (!targetPlayer) {
            ctx.source.sendFailure(Text.red("Jugador '" + username + "' no encontrado o está offline."));
            return 0;
        }
        
        targetPlayer.persistentData.putBoolean('isMuted', true);
        targetPlayer.persistentData.putString('muteReason', reason);
        
        console.info("[MUTE-PLAYER] console muted " + targetPlayer.username + " reason: " + reason);
        targetPlayer.tell(Text.red("§c§l[MUTADO] §fHas sido silenciado por un administrador. Motivo: §7" + reason));
        
        ctx.source.sendSuccess(Text.green("Jugador " + targetPlayer.username + " silenciado."), true);
        return 1;
    }

    function toggleFly(player, source) {
        var mayFly = !player.abilities.mayfly;
        player.abilities.mayfly = mayFly;
        if (!mayFly) {
            player.abilities.flying = false;
        }
        player.sendAbilities();
        
        player.tell(Text.yellow("§7[§6Moderación§7] §fVuelo establecido a: §b" + (mayFly ? "ACTIVADO" : "DESACTIVADO")));
        source.sendSuccess(Text.green("Vuelo de " + player.username + " establecido a: " + (mayFly ? "ACTIVADO" : "DESACTIVADO")), true);
    }

    function toggleGod(player, source) {
        var invul = !player.abilities.invulnerable;
        player.abilities.invulnerable = invul;
        player.sendAbilities();
        
        player.tell(Text.yellow("§7[§6Moderación§7] §fModo Dios establecido a: §b" + (invul ? "ACTIVADO" : "DESACTIVADO")));
        source.sendSuccess(Text.green("Modo Dios de " + player.username + " establecido a: " + (invul ? "ACTIVADO" : "DESACTIVADO")), true);
    }

    function healPlayer(player, source) {
        player.health = player.maxHealth;
        player.foodLevel = 20;
        player.tell(Text.green("§7[§6Moderación§7] §aHas sido curado y alimentado por un administrador."));
        source.sendSuccess(Text.green("Jugador " + player.username + " curado por completo."), true);
    }

    function feedPlayer(player, source) {
        player.foodLevel = 20;
        player.tell(Text.of("§7[§6Moderación§7] §aTu alimentación ha sido restablecida por un administrador.").green());
        source.sendSuccess(Text.of("Jugador " + player.username + " alimentado por completo.").green(), true);
    }

    // --- NUEVOS COMANDOS RAPIDOS ---
    
    event.register(
        Commands.literal("tpa")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("target", Arguments.STRING.create(event))
                .executes(ctx => {
                    var targetName = Arguments.STRING.getResult(ctx, "target");
                    var source = ctx.source;
                    var player = source.player;
                    if (!player) return 0;
                    
                    var targetPlayer = source.server.players.find(function(p) {
                        return p.username.toLowerCase() === targetName.toLowerCase();
                    });
                    
                    if (!targetPlayer) {
                        source.sendFailure(Text.of("Jugador '" + targetName + "' no encontrado.").red());
                        return 0;
                    }
                    
                    player.server.runCommandSilent("effect give " + player.username + " minecraft:invisibility infinite 0 true");
                    player.server.runCommandSilent("gamemode spectator " + player.username);
                    player.teleportTo(targetPlayer.level.dimension, targetPlayer.x, targetPlayer.y, targetPlayer.z, targetPlayer.yaw, targetPlayer.pitch);
                    
                    player.tell(Text.of("§aTeletransportado a " + targetPlayer.username + " en modo espectador e invisible.").green());
                    return 1;
                })
            )
    );

    event.register(
        Commands.literal("invi")
            .requires(src => src.hasPermission(2))
            .executes(ctx => {
                var player = ctx.source.player;
                if (!player) return 0;
                
                if (player.hasEffect('minecraft:invisibility')) {
                    player.server.runCommandSilent("effect clear " + player.username + " minecraft:invisibility");
                    player.tell(Text.of("§cInvisibilidad desactivada.").red());
                } else {
                    player.server.runCommandSilent("effect give " + player.username + " minecraft:invisibility infinite 0 true");
                    player.tell(Text.of("§aInvisibilidad activada (sin partículas).").green());
                }
                return 1;
            })
    );

    event.register(
        Commands.literal("nv")
            .requires(src => src.hasPermission(2))
            .executes(ctx => {
                var player = ctx.source.player;
                if (!player) return 0;
                
                if (player.hasEffect('minecraft:night_vision')) {
                    player.server.runCommandSilent("effect clear " + player.username + " minecraft:night_vision");
                    player.tell(Text.of("§cVisión nocturna desactivada.").red());
                } else {
                    player.server.runCommandSilent("effect give " + player.username + " minecraft:night_vision infinite 0 true");
                    player.tell(Text.of("§aVisión nocturna activada (sin partículas).").green());
                }
                return 1;
            })
    );
});
