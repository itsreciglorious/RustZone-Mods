// priority: 0
console.info('Loaded moderation.js');

if (typeof global.spawnLockEnabled === 'undefined') {
    global.spawnLockEnabled = false;
}

PlayerEvents.chat(event => {
    var player = event.player;
    if (player) {
        if (player.persistentData.getBoolean('isMuted')) {
            var reason = player.persistentData.getString('muteReason') || "Ninguno";
            player.tell(Text.red("§cNo puedes hablar. Estás silenciado por un administrador. Motivo: " + reason));
            event.cancel();
            return;
        }

        // Color chat permission for contribuidor++ (Tier 3) or Founder
        var hasColorChat = false;
        try {
            var resolvedRank = player.persistentData.getString("customTabRank");
            if (resolvedRank) {
                resolvedRank = resolvedRank.toString().toLowerCase();
            } else {
                resolvedRank = "";
            }
            
            if (!resolvedRank) {
                var LuckPermsProvider = Java.loadClass('net.luckperms.api.LuckPermsProvider');
                var luckPerms = LuckPermsProvider.get();
                var uuid = player.getUuid ? player.getUuid() : (player.getUUID ? player.getUUID() : player.uuid);
                var user = luckPerms.getUserManager()["getUser(java.util.UUID)"](uuid);
                if (user) {
                    var prefix = user.getCachedData().getMetaData().getPrefix();
                    if (prefix) {
                        var prefixStr = prefix.toString();
                        if (prefixStr.indexOf("💎++") > -1 || prefixStr.indexOf("👑") > -1) {
                            hasColorChat = true;
                        }
                    }
                }
            } else if (resolvedRank === "contribuidor++" || resolvedRank === "fundador") {
                hasColorChat = true;
            }
        } catch (e) {
            console.error("Error checking color chat permission for " + player.username + ": " + e);
        }

        if (hasColorChat) {
            var message = event.message;
            if (message && message.indexOf('&') > -1) {
                event.setMessage(message.replace(/&/g, '§'));
            }
        }
    }
});

PlayerEvents.tick(event => {
    var player = event.player;
    if (!player) return;

    // Cosmetic Particles Logic
    try {
        var tickCount = player.server.tickCount;
        // Spawning frequency: once every 4 ticks (5 times a second) to avoid lag
        if (tickCount % 4 === 0) {
            var activeEffect = player.persistentData.getString("activeParticleEffect");
            if (activeEffect && activeEffect.toString() !== "" && activeEffect.toString() !== "desactivar") {
                // Verify permission
                if (hasParticlePermission(player)) {
                    // Determine if moving
                    var lastX = player.persistentData.getDouble("lastPartX") || 0;
                    var lastZ = player.persistentData.getDouble("lastPartZ") || 0;
                    var isMoving = (Math.abs(player.x - lastX) > 0.05 || Math.abs(player.z - lastZ) > 0.05);
                    
                    // Update last position
                    player.persistentData.putDouble("lastPartX", player.x);
                    player.persistentData.putDouble("lastPartZ", player.z);
                    
                    var effectStr = activeEffect.toString();
                    var pType = "";
                    var pCount = 2;
                    var dx = 0.2;
                    var dy = 0.2;
                    var dz = 0.2;
                    var speed = 0.01;
                    var yOffset = 0.1;
                    
                    if (effectStr === "fuego") {
                        pType = "minecraft:flame";
                        if (isMoving) {
                            pCount = 3;
                            yOffset = 0.05;
                        } else {
                            pCount = 1;
                            yOffset = 1.0;
                            dy = 0.5;
                            speed = 0.02;
                        }
                    } else if (effectStr === "corazones") {
                        pType = "minecraft:heart";
                        if (isMoving) {
                            pCount = 1;
                            yOffset = 0.1;
                        } else {
                            // Standing: spawn above head occasionally
                            if (tickCount % 20 === 0) { // every 1 second
                                pCount = 1;
                                yOffset = 2.1;
                                dx = 0.1;
                                dy = 0.1;
                                dz = 0.1;
                            } else {
                                pCount = 0;
                            }
                        }
                    } else if (effectStr === "portal") {
                        pType = "minecraft:portal";
                        if (isMoving) {
                            pCount = 6;
                            yOffset = 0.2;
                            speed = 0.1;
                        } else {
                            pCount = 4;
                            yOffset = 1.0;
                            dy = 0.8;
                            speed = 0.05;
                        }
                    } else if (effectStr === "hojas") {
                        pType = "minecraft:cherry_leaves";
                        if (isMoving) {
                            pCount = 2;
                            yOffset = 0.5;
                            dy = 0.3;
                        } else {
                            pCount = 1;
                            yOffset = 2.3; // fall from above
                            dx = 0.5;
                            dz = 0.5;
                        }
                    } else if (effectStr === "estrellas") {
                        pType = "minecraft:happy_villager";
                        if (isMoving) {
                            pCount = 3;
                            yOffset = 0.1;
                        } else {
                            pCount = 2;
                            yOffset = 1.0;
                            dy = 0.6;
                        }
                    }
                    
                    if (pCount > 0 && pType !== "") {
                        player.server.runCommandSilent("execute at " + player.username + " run particle " + pType + " ~ ~" + yOffset + " ~ " + dx + " " + dy + " " + dz + " " + speed + " " + pCount + " normal");
                    }
                } else {
                    // Player lost permission, clear effect
                    player.persistentData.remove("activeParticleEffect");
                }
            }
        }
    } catch (e) {
        console.error("Error ticking cosmetic particles: " + e);
    }

    // Spawn-Lock logic
    if (global.spawnLockEnabled) {
        if (player.username.toLowerCase() !== 'itsreciglorious_' && player.username.toLowerCase() !== 'itsfreciglorious_') {
            var isCreativeOrSpectator = player.gamemode == 'creative' || player.gamemode == 'spectator';
            if (!isCreativeOrSpectator) {
                var dx = player.x - 2578;
                var dz = player.z - (-458);
                var distSq = dx * dx + dz * dz;
                if (distSq > 1521) { // 39 * 39 = 1521
                    player.teleportTo(player.level.dimension, 2578, 69, -458, player.yaw, player.pitch);
                    player.tell(Text.red("§cEl spawn está bloqueado temporalmente por un administrador. No puedes alejarte más de 39 bloques."));
                }
            }
        }
    }

    // Freeze logic
    if (player.persistentData.getBoolean('isFrozen')) {
        player.server.runCommandSilent("effect give " + player.username + " minecraft:slowness 2 255 true");
        player.server.runCommandSilent("effect give " + player.username + " minecraft:jump_boost 2 250 true");
        
        var fx = player.persistentData.getDouble('freezeX');
        var fy = player.persistentData.getDouble('freezeY');
        var fz = player.persistentData.getDouble('freezeZ');
        if (fx && fy && fz) {
            var dist = Math.sqrt(Math.pow(player.x - fx, 2) + Math.pow(player.y - fy, 2) + Math.pow(player.z - fz, 2));
            if (dist > 0.3) {
                player.teleportTo(player.level.dimension, fx, fy, fz, player.yaw, player.pitch);
            }
        }
    }

    // Spawn protection logic (X: 2578, Z: -458, radius: 40)
    if (player.username.toLowerCase() !== 'itsreciglorious_' && player.username.toLowerCase() !== 'itsfreciglorious_' && player.username.toLowerCase() !== 'andreness33') {
        var isCreativeOrSpectator = player.gamemode == 'creative' || player.gamemode == 'spectator';
        if (!isCreativeOrSpectator) {
            var dx = player.x - 2578;
            var dz = player.z - (-458);
            var inSpawn = (dx * dx + dz * dz) <= 1600; // 40 * 40 = 1600
            
            var state = player.persistentData.getInt('spawnProtectedState');
            if (state === 0) {
                // First tick / login -> Initialize silently
                player.persistentData.putInt('spawnProtectedState', inSpawn ? 1 : 2);
                if (inSpawn) {
                    if (player.gamemode != 'adventure') {
                        player.server.runCommandSilent("gamemode adventure " + player.username);
                    }
                } else {
                    if (player.gamemode != 'survival') {
                        player.server.runCommandSilent("gamemode survival " + player.username);
                    }
                }
            } else if (state === 1 && !inSpawn) {
                // Just left spawn
                player.persistentData.putInt('spawnProtectedState', 2);
                if (player.gamemode != 'survival') {
                    player.server.runCommandSilent("gamemode survival " + player.username);
                }
                player.tell(Text.of("§6§l» §aHas salido de la zona protegida del Spawn. Modo Supervivencia activado. ¡Ten cuidado!").green());
            } else if (state === 2 && inSpawn) {
                // Just entered spawn
                player.persistentData.putInt('spawnProtectedState', 1);
                if (player.gamemode != 'adventure') {
                    player.server.runCommandSilent("gamemode adventure " + player.username);
                }
                player.tell(Text.of("§6§l» §eHas entrado a la zona protegida del Spawn. Modo Aventura activado.").yellow());
            } else {
                // Maintain/enforce current state in case gamemode is modified manually
                if (inSpawn) {
                    if (player.gamemode != 'adventure') {
                        player.server.runCommandSilent("gamemode adventure " + player.username);
                    }
                } else {
                    if (player.gamemode != 'survival') {
                        player.server.runCommandSilent("gamemode survival " + player.username);
                    }
                }
            }
        }
    }
});

ServerEvents.commandRegistry(event => {
    const { commands: Commands, arguments: Arguments } = event;

    // Command: /spawn-lock <on/off>
    event.register(
        Commands.literal("spawn-lock")
            .requires(src => src.hasPermission(2))
            .then(Commands.literal("on")
                .executes(ctx => {
                    global.spawnLockEnabled = true;
                    ctx.source.sendSuccess(Text.green("Spawn lock activado. Los jugadores no pueden alejarse más de 39 bloques del spawn."), true);
                    ctx.source.server.tell(Text.yellow("§7[§6Servidor§7] §cEl bloqueo del spawn ha sido ACTIVADO. Por favor, espera en el spawn a que comience la partida."));
                    return 1;
                })
            )
            .then(Commands.literal("off")
                .executes(ctx => {
                    global.spawnLockEnabled = false;
                    ctx.source.sendSuccess(Text.green("Spawn lock desactivado."), true);
                    ctx.source.server.tell(Text.yellow("§7[§6Servidor§7] §aEl bloqueo del spawn ha sido DESACTIVADO. ¡Ya puedes explorar el mundo!"));
                    return 1;
                })
            )
    );

    // Command: /warn <player> [reason]
    event.register(
        Commands.literal("warn")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .then(Commands.argument("reason", Arguments.GREEDY_STRING.create(event))
                    .executes(ctx => {
                        var username = Arguments.STRING.getResult(ctx, "player");
                        var reason = Arguments.GREEDY_STRING.getResult(ctx, "reason");
                        return runWarn(ctx, username, reason);
                    })
                )
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    return runWarn(ctx, username, "Incumplimiento de normas");
                })
            )
    );

    // Command: /mute <player> [reason]
    event.register(
        Commands.literal("mute")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .then(Commands.argument("reason", Arguments.GREEDY_STRING.create(event))
                    .executes(ctx => {
                        var username = Arguments.STRING.getResult(ctx, "player");
                        var reason = Arguments.GREEDY_STRING.getResult(ctx, "reason");
                        return runMute(ctx, username, reason);
                    })
                )
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    return runMute(ctx, username, "Comportamiento inadecuado");
                })
            )
    );

    // Command: /unmute <player>
    event.register(
        Commands.literal("unmute")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    var server = ctx.source.server;
                    var targetPlayer = server.players.find(function(p) {
                        return p.username.toLowerCase() === username.toLowerCase();
                    });
                    
                    // Even if the player is offline, we log it so backend can sync unmute
                    console.info("[UNMUTE-PLAYER] console unmuted " + username);
                    
                    if (targetPlayer) {
                        targetPlayer.persistentData.putBoolean('isMuted', false);
                        targetPlayer.persistentData.remove('muteReason');
                        targetPlayer.tell(Text.green("§aHas sido desmuteado. Ya puedes hablar en el chat."));
                        ctx.source.sendSuccess(Text.green("Jugador " + targetPlayer.username + " desmuteado."), true);
                    } else {
                        ctx.source.sendSuccess(Text.yellow("Jugador '" + username + "' está offline, desmuteado en registros."), true);
                    }
                    return 1;
                })
            )
    );

    // Command: /freeze <player>
    event.register(
        Commands.literal("freeze")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    var server = ctx.source.server;
                    var targetPlayer = server.players.find(function(p) {
                        return p.username.toLowerCase() === username.toLowerCase();
                    });
                    
                    if (!targetPlayer) {
                        ctx.source.sendFailure(Text.red("Jugador '" + username + "' no encontrado o está offline."));
                        return 0;
                    }
                    
                    targetPlayer.persistentData.putBoolean('isFrozen', true);
                    targetPlayer.persistentData.putDouble('freezeX', targetPlayer.x);
                    targetPlayer.persistentData.putDouble('freezeY', targetPlayer.y);
                    targetPlayer.persistentData.putDouble('freezeZ', targetPlayer.z);
                    
                    targetPlayer.tell(Text.red("§c§l¡HAS SIDO CONGELADO POR UN ADMINISTRADOR! NO INTENTES MOVERTE NI SALIR."));
                    console.info("[FREEZE-PLAYER] console froze " + targetPlayer.username);
                    ctx.source.sendSuccess(Text.green("Jugador " + targetPlayer.username + " congelado con éxito."), true);
                    return 1;
                })
            )
    );

    // Command: /unfreeze <player>
    event.register(
        Commands.literal("unfreeze")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    var server = ctx.source.server;
                    var targetPlayer = server.players.find(function(p) {
                        return p.username.toLowerCase() === username.toLowerCase();
                    });
                    
                    console.info("[UNFREEZE-PLAYER] console unfroze " + username);
                    
                    if (targetPlayer) {
                        targetPlayer.persistentData.putBoolean('isFrozen', false);
                        targetPlayer.persistentData.remove('freezeX');
                        targetPlayer.persistentData.remove('freezeY');
                        targetPlayer.persistentData.remove('freezeZ');
                        
                        // Clear effects
                        server.runCommandSilent("effect clear " + targetPlayer.username + " minecraft:slowness");
                        server.runCommandSilent("effect clear " + targetPlayer.username + " minecraft:jump_boost");
                        
                        targetPlayer.tell(Text.green("§aHas sido descongelado. Ya puedes moverte libremente."));
                        ctx.source.sendSuccess(Text.green("Jugador " + targetPlayer.username + " descongelado."), true);
                    } else {
                        ctx.source.sendSuccess(Text.yellow("Jugador '" + username + "' está offline, descongelado en registros."), true);
                    }
                    return 1;
                })
            )
    );

    // Command: /fly [player]
    event.register(
        Commands.literal("fly")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    var server = ctx.source.server;
                    var targetPlayer = server.players.find(function(p) {
                        return p.username.toLowerCase() === username.toLowerCase();
                    });
                    if (!targetPlayer) {
                        ctx.source.sendFailure(Text.red("Jugador '" + username + "' no encontrado."));
                        return 0;
                    }
                    toggleFly(targetPlayer, ctx.source);
                    return 1;
                })
            )
            .executes(ctx => {
                var player = ctx.source.player;
                if (!player) {
                    ctx.source.sendFailure(Text.red("Este comando requiere especificar un jugador desde la consola."));
                    return 0;
                }
                toggleFly(player, ctx.source);
                return 1;
            })
    );

    // Command: /god [player]
    event.register(
        Commands.literal("god")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    var server = ctx.source.server;
                    var targetPlayer = server.players.find(function(p) {
                        return p.username.toLowerCase() === username.toLowerCase();
                    });
                    if (!targetPlayer) {
                        ctx.source.sendFailure(Text.red("Jugador '" + username + "' no encontrado."));
                        return 0;
                    }
                    toggleGod(targetPlayer, ctx.source);
                    return 1;
                })
            )
            .executes(ctx => {
                var player = ctx.source.player;
                if (!player) {
                    ctx.source.sendFailure(Text.red("Este comando requiere especificar un jugador desde la consola."));
                    return 0;
                }
                toggleGod(player, ctx.source);
                return 1;
            })
    );

    // Command: /heal [player]
    event.register(
        Commands.literal("heal")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    var server = ctx.source.server;
                    var targetPlayer = server.players.find(function(p) {
                        return p.username.toLowerCase() === username.toLowerCase();
                    });
                    if (!targetPlayer) {
                        ctx.source.sendFailure(Text.red("Jugador '" + username + "' no encontrado."));
                        return 0;
                    }
                    healPlayer(targetPlayer, ctx.source);
                    return 1;
                })
            )
            .executes(ctx => {
                var player = ctx.source.player;
                if (!player) {
                    ctx.source.sendFailure(Text.red("Este comando requiere especificar un jugador desde la consola."));
                    return 0;
                }
                healPlayer(player, ctx.source);
                return 1;
            })
    );

    // Command: /feed [player]
    event.register(
        Commands.literal("feed")
            .requires(src => src.hasPermission(2))
            .then(Commands.argument("player", Arguments.STRING.create(event))
                .executes(ctx => {
                    var username = Arguments.STRING.getResult(ctx, "player");
                    var server = ctx.source.server;
                    var targetPlayer = server.players.find(function(p) {
                        return p.username.toLowerCase() === username.toLowerCase();
                    });
                    if (!targetPlayer) {
                        ctx.source.sendFailure(Text.red("Jugador '" + username + "' no encontrado."));
                        return 0;
                    }
                    feedPlayer(targetPlayer, ctx.source);
                    return 1;
                })
            )
            .executes(ctx => {
                var player = ctx.source.player;
                if (!player) {
                    ctx.source.sendFailure(Text.red("Este comando requiere especificar un jugador desde la consola."));
                    return 0;
                }
                feedPlayer(player, ctx.source);
                return 1;
            })
    );

    // Command: /vista-rango <rango>
    event.register(
        Commands.literal("vista-rango")
            .then(Commands.argument("rango", Arguments.GREEDY_STRING.create(event))
                .executes(ctx => {
                    var rankStr = Arguments.GREEDY_STRING.getResult(ctx, "rango");
                    return runVistaRango(ctx, rankStr);
                })
            )
    );

    // Command: /rename <nombre>
    event.register(
        Commands.literal("rename")
            .then(Commands.argument("nombre", Arguments.GREEDY_STRING.create(event))
                .executes(ctx => {
                    var nameStr = Arguments.GREEDY_STRING.getResult(ctx, "nombre");
                    return runRename(ctx, nameStr);
                })
            )
    );

    // Command: /particulas
    event.register(
        Commands.literal("particulas")
            .then(Commands.literal("select")
                .then(Commands.argument("efecto", Arguments.STRING.create(event))
                    .executes(ctx => {
                        var effectStr = Arguments.STRING.getResult(ctx, "efecto");
                        return runSelectParticula(ctx, effectStr);
                    })
                )
            )
            .executes(ctx => {
                return runMenuParticulas(ctx);
            })
    );

    // Command: /particulas-dinamicas (alias)
    event.register(
        Commands.literal("particulas-dinamicas")
            .then(Commands.literal("select")
                .then(Commands.argument("efecto", Arguments.STRING.create(event))
                    .executes(ctx => {
                        var effectStr = Arguments.STRING.getResult(ctx, "efecto");
                        return runSelectParticula(ctx, effectStr);
                    })
                )
            )
            .executes(ctx => {
                return runMenuParticulas(ctx);
            })
    );

    function runVistaRango(ctx, rankStr) {
        var player = ctx.source.player;
        if (!player) {
            ctx.source.sendFailure(Text.red("Este comando solo puede ser ejecutado por un jugador."));
            return 0;
        }

        // Check if player is ItsReciGlorious_ OR has LuckPerms group 'fundador'
        var isFounder = player.username === "ItsReciGlorious_" || player.username === "ItsFreciGlorious_";
        if (!isFounder) {
            try {
                var LuckPermsProvider = Java.loadClass('net.luckperms.api.LuckPermsProvider');
                var luckPerms = LuckPermsProvider.get();
                var uuid = player.getUuid ? player.getUuid() : (player.getUUID ? player.getUUID() : player.uuid);
                var user = luckPerms.getUserManager()["getUser(java.util.UUID)"](uuid);
                if (user) {
                    var group = user.getPrimaryGroup();
                    if (group && group.toLowerCase() === "fundador") {
                        isFounder = true;
                    }
                }
            } catch (e) {
                console.error("Error checking LuckPerms group for " + player.username + ": " + e);
            }
        }

        if (!isFounder) {
            player.tell(Text.red("§cNo tienes permiso para ejecutar este comando. Solo los Fundadores pueden usar /vista-rango."));
            return 0;
        }

        var validRanks = ["sobreviviente", "contribuidor", "contribuidor+", "contribuidor++", "fundador", "clear"];
        var resolvedRank = rankStr.toLowerCase().trim();

        if (validRanks.indexOf(resolvedRank) === -1) {
            player.tell(Text.red("§cRango no válido. Rangos válidos: Sobreviviente, Contribuidor, Contribuidor+, Contribuidor++, Fundador (o 'clear' para restablecer)."));
            return 0;
        }

        if (resolvedRank === "clear") {
            // Remove persistent NBT tag
            player.persistentData.remove("customTabRank");
            
            // Print console info log for backend to sync actual group from LP
            console.info("[SET-VISTA-RANGO] " + player.username + " set visual rank clear");
            
            // Update immediately in-game
            updatePlayerTabName(player);
            
            player.tell(Text.green("§aTu rango visual ha sido restablecido a tu rango original."));
            return 1;
        }

        // Capitalize for DB and Tab
        var displayRank = resolvedRank;
        if (resolvedRank === "sobreviviente") displayRank = "Sobreviviente";
        else if (resolvedRank === "contribuidor") displayRank = "Contribuidor";
        else if (resolvedRank === "contribuidor+") displayRank = "Contribuidor+";
        else if (resolvedRank === "contribuidor++") displayRank = "Contribuidor++";
        else if (resolvedRank === "fundador") displayRank = "Fundador";

        // Store in persistent data for Tab list prefix override
        player.persistentData.putString("customTabRank", resolvedRank);

        // Print console info log for backend listener to catch and update DB
        console.info("[SET-VISTA-RANGO] " + player.username + " set visual rank " + displayRank);

        // Update player Tab List immediately
        updatePlayerTabName(player);

        player.tell(Text.green("§aTu rango visual para Tab y Frontend ha sido actualizado a: §l" + displayRank));
        return 1;
    }

    function runRename(ctx, nameStr) {
        var player = ctx.source.player;
        if (!player) {
            ctx.source.sendFailure(Text.red("Este comando solo puede ser ejecutado por un jugador."));
            return 0;
        }

        // Check if player is ItsReciGlorious_ OR has group 'fundador' OR 'contribuidor++'
        var hasPermission = player.username === "ItsReciGlorious_" || player.username === "ItsFreciGlorious_";
        if (!hasPermission) {
            try {
                var resolvedRank = player.persistentData.getString("customTabRank");
                if (resolvedRank) {
                    resolvedRank = resolvedRank.toString().toLowerCase();
                } else {
                    resolvedRank = "";
                }
                
                if (!resolvedRank) {
                    var LuckPermsProvider = Java.loadClass('net.luckperms.api.LuckPermsProvider');
                    var luckPerms = LuckPermsProvider.get();
                    var uuid = player.getUuid ? player.getUuid() : (player.getUUID ? player.getUUID() : player.uuid);
                    var user = luckPerms.getUserManager()["getUser(java.util.UUID)"](uuid);
                    if (user) {
                        var prefix = user.getCachedData().getMetaData().getPrefix();
                        if (prefix) {
                            var prefixStr = prefix.toString();
                            if (prefixStr.indexOf("💎++") > -1 || prefixStr.indexOf("👑") > -1) {
                                hasPermission = true;
                            }
                        }
                    }
                } else if (resolvedRank === "contribuidor++" || resolvedRank === "fundador") {
                    hasPermission = true;
                }
            } catch (e) {
                console.error("Error checking LuckPerms group for " + player.username + ": " + e);
            }
        }

        if (!hasPermission) {
            player.tell(Text.red("§cNo tienes permiso para ejecutar este comando. Requiere rango Contribuidor++ o superior."));
            return 0;
        }

        var item = player.getMainHandItem();
        if (item.isEmpty()) {
            player.tell(Text.red("§cDebes sostener un objeto en tu mano principal para renombrarlo."));
            return 0;
        }

        // Replace '&' with '§' to parse color codes
        var formattedName = nameStr.replace(/&/g, '§');

        // Set the custom name
        item.setHoverName(Text.of(formattedName));
        player.tell(Text.green("§a¡Objeto renombrado con éxito a: §r" + formattedName));
        return 1;
    }

    function hasParticlePermission(player) {
        var isFounder = player.username === "ItsReciGlorious_" || player.username === "ItsFreciGlorious_";
        if (isFounder) return true;
        try {
            var resolvedRank = player.persistentData.getString("customTabRank");
            if (resolvedRank) {
                resolvedRank = resolvedRank.toString().toLowerCase();
            } else {
                resolvedRank = "";
            }
            
            if (!resolvedRank) {
                var LuckPermsProvider = Java.loadClass('net.luckperms.api.LuckPermsProvider');
                var luckPerms = LuckPermsProvider.get();
                var uuid = player.getUuid ? player.getUuid() : (player.getUUID ? player.getUUID() : player.uuid);
                var user = luckPerms.getUserManager()["getUser(java.util.UUID)"](uuid);
                if (user) {
                    var prefix = user.getCachedData().getMetaData().getPrefix();
                    if (prefix) {
                        var prefixStr = prefix.toString();
                        if (prefixStr.indexOf("💎+") > -1 || prefixStr.indexOf("💎++") > -1 || prefixStr.indexOf("👑") > -1) {
                            return true;
                        }
                    }
                }
            } else if (resolvedRank === "contribuidor+" || resolvedRank === "contribuidor++" || resolvedRank === "fundador") {
                return true;
            }
        } catch (e) {
            console.error("Error checking particle permission: " + e);
        }
        return false;
    }

    function runMenuParticulas(ctx) {
        var player = ctx.source.player;
        if (!player) {
            ctx.source.sendFailure(Text.red("Este comando solo puede ser ejecutado por un jugador."));
            return 0;
        }

        if (!hasParticlePermission(player)) {
            player.tell(Text.red("§cNo tienes el rango necesario para usar el menú de partículas. Requiere rango Contribuidor+ o superior."));
            return 0;
        }

        player.tell(Text.of(" "));
        player.tell(Text.of("§6§l★ Menú de Partículas Estéticas ★").gold());
        player.tell(Text.of("§7Elige un efecto activo para lucir en el servidor:").gray());
        player.tell(
            Text.of(" §7- ").gray()
            .append(Text.of("🔥 [Fuego] ").red().click('run_command:/particulas select fuego').hover("§eActiva aura/rastro de fuego"))
            .append(Text.of("   💖 [Corazones] ").lightPurple().click('run_command:/particulas select corazones').hover("§eActiva aura/rastro de corazones"))
        );
        player.tell(
            Text.of(" §7- ").gray()
            .append(Text.of("🔮 [Portal] ").darkPurple().click('run_command:/particulas select portal').hover("§eActiva aura/rastro de portal"))
            .append(Text.of("   🌸 [Hojas] ").lightPurple().click('run_command:/particulas select hojas').hover("§eActiva hojas de cerezo cayendo"))
        );
        player.tell(
            Text.of(" §7- ").gray()
            .append(Text.of("⭐ [Estrellas] ").green().click('run_command:/particulas select estrellas').hover("§eActiva chispas verdes"))
            .append(Text.of("   ❌ [Desactivar] ").gray().click('run_command:/particulas select desactivar').hover("§eDesactivar todos los efectos"))
        );
        player.tell(Text.of(" "));
        return 1;
    }

    function runSelectParticula(ctx, effectStr) {
        var player = ctx.source.player;
        if (!player) {
            ctx.source.sendFailure(Text.red("Este comando solo puede ser ejecutado por un jugador."));
            return 0;
        }

        if (!hasParticlePermission(player)) {
            player.tell(Text.red("§cNo tienes el rango necesario para usar partículas. Requiere rango Contribuidor+ o superior."));
            return 0;
        }

        var validEffects = ["fuego", "corazones", "portal", "hojas", "estrellas", "desactivar"];
        var effect = effectStr.toLowerCase().trim();

        if (validEffects.indexOf(effect) === -1) {
            player.tell(Text.red("§cEfecto no válido. Escribe /particulas para ver las opciones disponibles."));
            return 0;
        }

        if (effect === "desactivar") {
            player.persistentData.remove("activeParticleEffect");
            player.tell(Text.green("§aTus efectos de partículas estéticas han sido desactivados."));
            return 1;
        }

        player.persistentData.putString("activeParticleEffect", effect);
        
        var displayNames = {
            "fuego": "§c§lFUEGO",
            "corazones": "§d§lCORAZONES",
            "portal": "§5§lPORTAL",
            "hojas": "§d§lHOJAS DE CEREZO",
            "estrellas": "§a§lESTRELLAS"
        };
        
        player.tell(Text.green("§a¡Efecto de partículas establecido con éxito a: " + displayNames[effect]));
        return 1;
    }

    function runWarn(ctx, username, reason) {
        var server = ctx.source.server;
        var targetPlayer = server.players.find(function(p) {
            return p.username.toLowerCase() === username.toLowerCase();
        });
        
        if (!targetPlayer) {
            ctx.source.sendFailure(Text.red("Jugador '" + username + "' no encontrado o está offline."));
            return 0;
        }
        
        var warnings = (targetPlayer.persistentData.getInt('warnings') || 0) + 1;
        targetPlayer.persistentData.putInt('warnings', warnings);
        
        // Broadcast / Log
        console.info("[WARN-PLAYER] console warned " + targetPlayer.username + " count " + warnings + " reason: " + reason);
        
        // Notify target player with titles
        server.runCommandSilent("title " + targetPlayer.username + " title {\"text\":\"§c§l¡HAS SIDO ADVERTIDO!\",\"bold\":true}");
        server.runCommandSilent("title " + targetPlayer.username + " subtitle {\"text\":\"§eAdvertencia " + warnings + "/3. Motivo: " + reason + "\"}");
        targetPlayer.tell(Text.red("§c§l[ADVERTENCIA] §fHas sido advertido por un administrador. §cTotal: " + warnings + "/3§f. Motivo: §7" + reason));
        
        ctx.source.sendSuccess(Text.green("Jugador " + targetPlayer.username + " advertido (" + warnings + "/3)."), true);
        
        if (warnings >= 3) {
            targetPlayer.persistentData.putInt('warnings', 0);
            server.runCommandSilent("kick " + targetPlayer.username + " §cExpulsado del servidor por acumulación de 3 advertencias.");
            server.runCommandSilent("tellraw @a {\"text\":\"§7[§cModeración§7] §e" + targetPlayer.username + " §fha sido expulsado por acumulación de 3 advertencias.\"}");
        }
        return 1;
    }

    function runMute(ctx, username, reason) {
        var server = ctx.source.server;
        var targetPlayer = server.players.find(function(p) {
            return p.username.toLowerCase() === username.toLowerCase();
        });
        
        if (!targetPlayer) {
            ctx.source.sendFailure(Text.red("Jugador '" + username + "' no encontrado o está offline."));
            return 0;
        }
        
        targetPlayer.persistentData.putBoolean('isMuted', true);
        targetPlayer.persistentData.putString('muteReason', reason);
        
        console.info("[MUTE-PLAYER] console muted " + targetPlayer.username + " reason: " + reason);
        targetPlayer.tell(Text.red("§c§l[MUTADO] §fHas sido silenciado por un administrador. Motivo: §7" + reason));
        
        ctx.source.sendSuccess(Text.green("Jugador " + targetPlayer.username + " silenciado."), true);
        return 1;
    }

    function toggleFly(player, source) {
        var mayFly = !player.abilities.mayfly;
        player.abilities.mayfly = mayFly;
        if (!mayFly) {
            player.abilities.flying = false;
        }
        player.sendAbilities();
        
        player.tell(Text.yellow("§7[§6Moderación§7] §fVuelo establecido a: §b" + (mayFly ? "ACTIVADO" : "DESACTIVADO")));
        source.sendSuccess(Text.green("Vuelo de " + player.username + " establecido a: " + (mayFly ? "ACTIVADO" : "DESACTIVADO")), true);
    }

    function toggleGod(player, source) {
        var invul = !player.abilities.invulnerable;
        player.abilities.invulnerable = invul;
        player.sendAbilities();
        
        player.tell(Text.yellow("§7[§6Moderación§7] §fModo Dios establecido a: §b" + (invul ? "ACTIVADO" : "DESACTIVADO")));
        source.sendSuccess(Text.green("Modo Dios de " + player.username + " establecido a: " + (invul ? "ACTIVADO" : "DESACTIVADO")), true);
    }

    function healPlayer(player, source) {
        player.health = player.maxHealth;
        player.foodLevel = 20;
        player.tell(Text.green("§7[§6Moderación§7] §aHas sido curado y alimentado por un administrador."));
        source.sendSuccess(Text.green("Jugador " + player.username + " curado por completo."), true);
    }

    function feedPlayer(player, source) {
        player.foodLevel = 20;
        player.tell(Text.green("§7[§6Moderación§7] §aTu alimentación ha sido restablecida por un administrador."));
        source.sendSuccess(Text.green("Jugador " + player.username + " alimentado por completo."), true);
    }
});
