ServerEvents.commandRegistry(event => {
    const { commands: Commands, arguments: Arguments } = event;
    
    event.register(
        Commands.literal('resetbase')
            .requires(src => src.hasPermission(2)) // requiere admin (op)
            .then(Commands.argument('jugador', Arguments.PLAYER.create(event))
                .executes(ctx => {
                    const player = Arguments.PLAYER.getResult(ctx, 'jugador');
                    
                    if (player.persistentData.getBoolean('hasBaseCrystalPos')) {
                        player.persistentData.remove('hasBaseCrystalPos');
                        player.persistentData.remove('baseX');
                        player.persistentData.remove('baseY');
                        player.persistentData.remove('baseZ');
                        player.persistentData.remove('baseDim');
                        
                        ctx.source.sendSuccess(Text.green(`La base personal de ${player.username} ha sido borrada con éxito.`), true);
                        player.tell(Text.yellow('Un administrador ha reiniciado tu Punto de Retorno Personal. Ya puedes usar un Cristal de Base para registrar una nueva ubicación.'));
                    } else {
                        ctx.source.sendSuccess(Text.red(`El jugador ${player.username} no tiene ninguna base registrada.`), false);
                    }
                    
                    return 1;
                })
            )
    );
});
