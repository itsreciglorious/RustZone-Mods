// ==========================================
// RECONSTRUCCIÓN AUTOMÁTICA Y MANUAL DE PLANTILLAS DE SUMINISTROS
// ==========================================

var templatesRebuilt = false;

function rebuildTemplate(level, jsonPath, originX, originY, originZ) {
    try {
        var data = JsonIO.read(jsonPath);
        if (!data || !data.blocks) {
            console.error("Could not load structure file or it is empty: " + jsonPath);
            return false;
        }
        var blocks = data.blocks;
        
        console.log("Rebuilding structure from " + jsonPath + " at X:" + originX + " Y:" + originY + " Z:" + originZ);
        var successCount = 0;
        var failCount = 0;
        for (var i = 0; i < blocks.length; i++) {
            var b = blocks[i];
            var x = originX + b.relX;
            var y = originY + b.relY;
            var z = originZ + b.relZ;
            
            try {
                var block = level.getBlock(x, y, z);
                if (b.properties && Object.keys(b.properties).length > 0) {
                    block.set(b.id, b.properties);
                } else {
                    block.set(b.id);
                }
                successCount++;
            } catch(blockErr) {
                failCount++;
                if (failCount <= 5) {
                    console.error("Failed to set block " + b.id + " at rel (" + b.relX + ", " + b.relY + ", " + b.relZ + ") with props " + JSON.stringify(b.properties) + ": " + blockErr);
                }
            }
        }
        console.log("Rebuilt " + jsonPath + ": " + successCount + " succeeded, " + failCount + " failed");
        return failCount === 0;
    } catch(e) {
        console.error("Error rebuilding template from " + jsonPath + ": " + e);
        return false;
    }
}

// Registro del comando manual: /rebuild-templates
ServerEvents.commandRegistry(event => {
    const { commands: Commands } = event;
    
    event.register(
        Commands.literal("rebuild-templates")
            .requires(src => src.hasPermission(2)) // Requiere OP
            .executes(ctx => {
                var server = ctx.source.server;
                var level = server.getLevel("minecraft:overworld");
                if (!level) {
                    level = server.overworld();
                }
                
                ctx.source.sendSuccess(Text.yellow("Iniciando reconstrucción manual de plantillas de drops..."), true);
                
                // Asegurar forceload en la zona de las plantillas
                server.runCommandSilent("forceload add -24 -4 4 4");
                
                var success1 = rebuildTemplate(level, "kubejs/data/rustzone/structures/tier1.json", -4, -21, -4);
                var success2 = rebuildTemplate(level, "kubejs/data/rustzone/structures/tier2.json", -14, -21, -4);
                var success3 = rebuildTemplate(level, "kubejs/data/rustzone/structures/tier3.json", -24, -21, -4);
                
                if (success1 && success2 && success3) {
                    ctx.source.sendSuccess(Text.green("¡Plantillas de drops reconstruidas con éxito!"), true);
                } else {
                    ctx.source.sendFailure(Text.red("Ocurrió un error al reconstruir algunas plantillas. Ver logs."));
                }
                return 1;
            })
    );
});

// Reconstrucción automática a los 5 segundos de iniciar el servidor (100 ticks)
ServerEvents.tick(event => {
    if (templatesRebuilt) return;
    
    var srv = event.server;
    if (srv.tickCount >= 100) {
        templatesRebuilt = true;
        var level = srv.getLevel("minecraft:overworld");
        if (!level) {
            level = srv.overworld();
        }
        
        console.log("=== AUTO REBUILDING TEMPLATE DROPS ===");
        srv.runCommandSilent("forceload add -24 -4 4 4");
        
        rebuildTemplate(level, "kubejs/data/rustzone/structures/tier1.json", -4, -21, -4);
        rebuildTemplate(level, "kubejs/data/rustzone/structures/tier2.json", -14, -21, -4);
        rebuildTemplate(level, "kubejs/data/rustzone/structures/tier3.json", -24, -21, -4);
        
        console.log("=== AUTO REBUILD TEMPLATES COMPLETED ===");
    }
});
