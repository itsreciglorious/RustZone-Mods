BlockEvents.broken('rust_zone_official_mod:scrap_heap', event => {
    const { block } = event;
    const x = block.x;
    const y = block.y;
    const z = block.z;
    
    // Coordenadas de la ciudad PvP proporcionadas por el usuario:
    // 8446, 60, -1202 hasta 8209, 151, -1423
    const minX = Math.min(8446, 8209); // 8209
    const maxX = Math.max(8446, 8209); // 8446
    const minY = Math.min(60, 151);    // 60
    const maxY = Math.max(60, 151);    // 151
    const minZ = Math.min(-1202, -1423); // -1423
    const maxZ = Math.max(-1202, -1423); // -1202
    
    // Verificar si el bloque que se rompió está dentro de los límites de la ciudad PvP
    if (x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ) {
        // No cancelamos el evento porque queremos que el bloque se rompa normalmente
        // y que el mod maneje su propio sistema de drops (recompensa).
        
        // Simplemente imprimimos un log especial que el demonio de Node.js interceptará
        const username = event.player ? event.player.username : "Unknown";
        console.info(`[SCRAP-NODE-MINED] ${x} ${y} ${z} ${username}`);
    }
});

ServerEvents.commandRegistry(event => {
    const { commands: Commands, arguments: Arguments } = event;
    event.register(
        Commands.literal('scrap_node_remove')
            .requires(src => src.hasPermission(2)) // Admin
            .executes(ctx => {
                const player = ctx.source.player;
                if (!player) return 0;
                
                const px = Math.floor(player.x);
                const py = Math.floor(player.y);
                const pz = Math.floor(player.z);
                const username = player.username;
                
                console.info(`[SCRAP-NODE-REMOVE] ${px} ${py} ${pz} ${username}`);
                player.tell('§eComando enviado para remover menas cercanas (radio de 5 bloques).');
                return 1;
            })
    );
});
