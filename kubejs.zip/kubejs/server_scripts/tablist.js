// ==========================================
// INTEGRACIÓN DE LUCKPERMS EN TAB LIST VIA SCOREBOARD TEAMS
// ==========================================

function getPveRank(kills) {
    if (kills >= 10000) return { name: 'Inmortal', prefix: '§8[INMORTAL] ' };
    if (kills >= 5000) return { name: 'Leyenda', prefix: '§e[Leyenda] ' };
    if (kills >= 2000) return { name: 'Aniquilador', prefix: '§3[Aniquilador] ' };
    if (kills >= 1000) return { name: 'Ejecutor', prefix: '§5[Ejecutor] ' };
    if (kills >= 500) return { name: 'Veterano', prefix: '§6[Veterano] ' };
    if (kills >= 250) return { name: 'Exterminador', prefix: '§b[Exterminador] ' };
    if (kills >= 100) return { name: 'Cazador', prefix: '§9[Cazador] ' };
    return { name: 'Recluta', prefix: '§7[Recluta] ' };
}

function getResolvedRankFromLp(user) {
    if (!user) return "";
    try {
        var prefix = user.getCachedData().getMetaData().getPrefix();
        if (prefix) {
            var prefixStr = prefix.toString();
            if (prefixStr.indexOf("👑") > -1) return "fundador";
            if (prefixStr.indexOf("💎++") > -1) return "contribuidor++";
            if (prefixStr.indexOf("💎+") > -1) return "contribuidor+";
            if (prefixStr.indexOf("💎") > -1) return "contribuidor";
            if (prefixStr.indexOf("🛡️") > -1) return "sobreviviente";
        }
    } catch (e) {
        console.error("Error reading prefix from LuckPerms user: " + e);
    }
    
    // Fallback to primary group
    var group = user.getPrimaryGroup();
    return group ? group.toLowerCase() : "";
}

function getPlayerPrefix(player, user) {
    var customOverride = player.persistentData.getString("customTabRank");
    var basePrefix = "§7[🛡️] §r§a";
    
    var resolvedRank = "";
    if (customOverride && customOverride.toString() !== "") {
        resolvedRank = customOverride.toString().toLowerCase();
    } else {
        var u = player.username.toLowerCase();
        if (u === "itsreciglorious" || u === "itsreciglorious_" || u === "itsfreciglorious" || u === "itsfreciglorious_") {
            resolvedRank = "fundador";
        } else if (user) {
            resolvedRank = getResolvedRankFromLp(user);
        }
    }
    
    if (resolvedRank === "fundador") {
        basePrefix = "§c[👑] §r§c";
    } else if (resolvedRank === "contribuidor") {
        basePrefix = "§d[💎] §r§d";
    } else if (resolvedRank === "contribuidor+") {
        basePrefix = "§d[💎+] §r§d";
    } else if (resolvedRank === "contribuidor++") {
        basePrefix = "§6[💎++] §r§6";
    } else {
        basePrefix = "§7[🛡️] §r§a";
    }
    
    // Obtener rango PvE desde NBT persistente
    var totalKills = player.persistentData.getInt('totalZombieKills') || 0;
    var pveRank = getPveRank(totalKills);
    
    return pveRank.prefix + basePrefix;
}

function getPlayerSuffixJson(user) {
    if (!user) return { text: "" };
    try {
        var metaData = user.getCachedData().getMetaData();
        var map = metaData.getSuffixes();
        var str = "";
        
        var iter = map.values().iterator();
        while (iter.hasNext()) {
            str += iter.next();
        }
        
        if (str.length > 0) {
            // Handle normal color codes
            str = str.replace(/&([0-9a-fk-or])/g, '§$1');
            
            // Very simple fallback for a single hex code just in case
            if (str.length >= 8 && str.startsWith("&#")) {
                var hex = str.substring(2, 8);
                var rest = str.substring(8);
                return [
                    { text: " " },
                    { text: rest, color: "#" + hex }
                ];
            }
            
            return { text: " " + str };
        }
    } catch (e) {
        console.error("Error reading suffixes from LuckPerms user: " + e);
    }
    return { text: "" };
}

function updatePlayerTabName(player, force) {
    if (force === undefined) force = true;
    try {
        var LuckPermsProvider = Java.loadClass('net.luckperms.api.LuckPermsProvider');
        var luckPerms = LuckPermsProvider.get();
        
        var uuid = null;
        if (typeof player.getUUID === 'function') {
            uuid = player.getUUID();
        } else if (typeof player.getUuid === 'function') {
            uuid = player.getUuid();
        } else {
            uuid = player.uuid;
        }
        
        if (!uuid) return;
        
        var user = luckPerms.getUserManager()["getUser(java.util.UUID)"](uuid);
        
        var formattedPrefix = getPlayerPrefix(player, user);
        var suffixJsonObj = getPlayerSuffixJson(user);
        var suffixJsonStr = JSON.stringify(suffixJsonObj);
        
        if (!force) {
            var lastPrefix = player.persistentData.getString("lastTabPrefix");
            var lastSuffix = player.persistentData.getString("lastTabSuffix");
            if (lastPrefix && lastPrefix.toString() === formattedPrefix && 
                lastSuffix && lastSuffix.toString() === suffixJsonStr) {
                return;
            }
        }
        
        // DEBUG:
        console.log("Updating tablist for " + player.username + ": prefix=" + formattedPrefix + " suffix=" + suffixJsonStr);
        
        player.persistentData.putString("lastTabPrefix", formattedPrefix);
        player.persistentData.putString("lastTabSuffix", suffixJsonStr);
        
        var teamName = "lp_" + player.username;
        var server = player.server;
        
        server.runCommandSilent("team add " + teamName);
        
        var prefixJson = JSON.stringify({ text: formattedPrefix });
        server.runCommandSilent("team modify " + teamName + " prefix " + prefixJson);
        
        server.runCommandSilent("team modify " + teamName + " suffix " + suffixJsonStr);
        
        server.runCommandSilent("team join " + teamName + " " + player.username);
    } catch (e) {
        console.error("Error updating tab prefix for " + player.username + ": " + e);
    }
}

// Actualizar al entrar al servidor
PlayerEvents.loggedIn(event => {
    updatePlayerTabName(event.player, true);

    // Custom join message for donors
    try {
        var player = event.player;
        var LuckPermsProvider = Java.loadClass('net.luckperms.api.LuckPermsProvider');
        var luckPerms = LuckPermsProvider.get();
        var uuid = player.getUuid ? player.getUuid() : (player.getUUID ? player.getUUID() : player.uuid);
        var user = luckPerms.getUserManager()["getUser(java.util.UUID)"](uuid);
        
        var resolvedRank = "";
        var u = player.username.toLowerCase();
        if (u === "itsreciglorious" || u === "itsreciglorious_" || u === "itsfreciglorious" || u === "itsfreciglorious_") {
            resolvedRank = "fundador";
        } else if (user) {
            resolvedRank = getResolvedRankFromLp(user);
        }
        
        var server = player.server;
        if (resolvedRank === "contribuidor+") {
            var joinMsg = '{"text":"[💎+] ¡El contribuidor ' + player.username + ' ha entrado al servidor!","color":"light_purple","bold":true}';
            server.runCommandSilent("tellraw @a " + joinMsg);
        } else if (resolvedRank === "contribuidor++") {
            var joinMsg = '{"text":"[💎++] ¡El súper contribuidor ' + player.username + ' ha entrado al servidor!","color":"gold","bold":true}';
            server.runCommandSilent("tellraw @a " + joinMsg);
        } else if (resolvedRank === "fundador") {
            var joinMsg = '{"text":"[👑] ¡El Fundador ' + player.username + ' ha entrado al servidor!","color":"red","bold":true}';
            server.runCommandSilent("tellraw @a " + joinMsg);
        }
    } catch (e) {
        console.error("Error sending custom login announcement: " + e);
    }
});

// Limpiar equipo al salir del servidor
PlayerEvents.loggedOut(event => {
    try {
        var teamName = "lp_" + event.player.username;
        event.server.runCommandSilent("team remove " + teamName);
    } catch (e) {
        // Ignorar errores al limpiar
    }
});

// Actualizar periódicamente cada 5 segundos (100 ticks) para reflejar cambios de rango en tiempo real
ServerEvents.tick(event => {
    var srv = event.server;
    if (srv.tickCount % 100 === 0) {
        srv.players.forEach(function(player) {
            updatePlayerTabName(player, false);
        });
    }
});
