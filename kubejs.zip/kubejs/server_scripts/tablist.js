// ==========================================
// INTEGRACIÓN DE LUCKPERMS EN TAB LIST VIA SCOREBOARD TEAMS
// ==========================================

function getPveRank(kills) {
    if (kills >= 5000) return { name: 'Leyenda', prefix: '§e[Leyenda] ' };
    if (kills >= 2000) return { name: 'Aniquilador', prefix: '§3[Aniquilador] ' };
    if (kills >= 1000) return { name: 'Ejecutor', prefix: '§5[Ejecutor] ' };
    if (kills >= 500) return { name: 'Veterano', prefix: '§6[Veterano] ' };
    if (kills >= 250) return { name: 'Exterminador', prefix: '§b[Exterminador] ' };
    if (kills >= 100) return { name: 'Cazador', prefix: '§9[Cazador] ' };
    return { name: 'Recluta', prefix: '§7[Recluta] ' };
}

function getPlayerPrefix(player, user) {
    var customOverride = player.persistentData.getString("customTabRank");
    var basePrefix = "§a§l[SOBREVIVIENTE] §r§a";
    
    var resolvedRank = "";
    if (customOverride && customOverride.toString() !== "") {
        resolvedRank = customOverride.toString().toLowerCase();
    } else {
        if (player.username === "ItsReciGlorious_") {
            resolvedRank = "fundador";
        } else if (user) {
            var group = user.getPrimaryGroup();
            resolvedRank = group ? group.toLowerCase() : "";
        }
    }
    
    if (resolvedRank === "fundador") {
        basePrefix = "§c§l[FUNDADOR] §r§c";
    } else if (resolvedRank === "contribuidor") {
        basePrefix = "§d§l[CONTRIBUIDOR] §r§d";
    } else if (resolvedRank === "contribuidor+") {
        basePrefix = "§d§l[CONTRIBUIDOR+] §r§d";
    } else if (resolvedRank === "contribuidor++") {
        basePrefix = "§6§l[CONTRIBUIDOR++] §r§6";
    } else {
        basePrefix = "§a§l[SOBREVIVIENTE] §r§a";
    }
    
    // Obtener rango PvE desde NBT persistente
    var totalKills = player.persistentData.getInt('totalZombieKills') || 0;
    var pveRank = getPveRank(totalKills);
    
    return pveRank.prefix + basePrefix;
}

function updatePlayerTabName(player) {
    try {
        var LuckPermsProvider = Java.loadClass('net.luckperms.api.LuckPermsProvider');
        var luckPerms = LuckPermsProvider.get();
        
        var uuid = null;
        if (typeof player.getUUID === 'function') {
            uuid = player.getUUID();
        } else if (typeof player.getUuid === 'function') {
            uuid = player.getUuid();
        } else {
            uuid = player.uuid;
        }
        
        if (!uuid) return;
        
        // Resolver la llamada ambigua a getUser en Rhino especificando la firma exacta
        var user = luckPerms.getUserManager()["getUser(java.util.UUID)"](uuid);
        
        var formattedPrefix = getPlayerPrefix(player, user);
        var teamName = "lp_" + player.username;
        var server = player.server;
        
        // Asegurar que el equipo existe (se ejecuta de forma silenciosa)
        server.runCommandSilent("team add " + teamName);
        
        // Establecer el prefijo en formato JSON
        var prefixJson = JSON.stringify({ text: formattedPrefix });
        server.runCommandSilent("team modify " + teamName + " prefix " + prefixJson);
        
        // Unir al jugador al equipo
        server.runCommandSilent("team join " + teamName + " " + player.username);
    } catch (e) {
        console.error("Error updating tab prefix for " + player.username + ": " + e);
    }
}

// Actualizar al entrar al servidor
PlayerEvents.loggedIn(event => {
    updatePlayerTabName(event.player);
});

// Limpiar equipo al salir del servidor
PlayerEvents.loggedOut(event => {
    try {
        var teamName = "lp_" + event.player.username;
        event.server.runCommandSilent("team remove " + teamName);
    } catch (e) {
        // Ignorar errores al limpiar
    }
});

// Actualizar periódicamente cada 5 segundos (100 ticks) para reflejar cambios de rango en tiempo real
ServerEvents.tick(event => {
    var srv = event.server;
    if (srv.tickCount % 100 === 0) {
        var onlinePlayers = srv.players;
        for (var i = 0; i < onlinePlayers.length; i++) {
            updatePlayerTabName(onlinePlayers[i]);
        }
    }
});
