// priority: 0

console.info("DUMPING MOD ITEM IDS...");
const modsToDump = ['tacz', 'legendarysurvivaloverhaul', 'create'];

let dumpedIds = [];

Item.getList().forEach(item => {
    let idStr = String(item.id);
    for (let mod of modsToDump) {
        if (idStr.startsWith(mod + ':')) {
            dumpedIds.push(idStr);
        }
    }
});

JsonIO.write('kubejs/dumped_mod_items.json', dumpedIds);
console.info("DUMPED " + dumpedIds.length + " ITEMS to kubejs/dumped_mod_items.json");
