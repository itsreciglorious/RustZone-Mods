ForgeEvents.onEvent('net.smileycorp.hordes.common.event.HordeEndEvent', event => {
    const player = event.getPlayer();
    if (player) {
        // Asegurarse de que no fue ejecutado por comando /hordes stop para evitar exploits
        if (!event.wasCommand()) {
            // Se usa getScoreboardName() para obtener el nombre del jugador desde el objeto Java nativo
            const username = player.getScoreboardName();
            console.info('[HORDE-COMPLETED] ' + username);
        }
    }
});
