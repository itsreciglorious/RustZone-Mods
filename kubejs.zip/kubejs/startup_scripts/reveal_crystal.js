StartupEvents.registry('item', event => {
    event.create('reveal_crystal')
        .displayName('§5Cristal Revelador')
        .tooltip('§7Rompe este cristal para revelar a los')
        .tooltip('§7jugadores invisibles cercanos (30 bloques).')
        .glow(true)
        .texture('minecraft:item/amethyst_shard')
        .maxStackSize(16);
});
