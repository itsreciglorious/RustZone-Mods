StartupEvents.registry('item', event => {
  event.create('teleport_crystal')
    .displayName('§dCristal de Teletransporte')
    .tooltip('§7Úsalo para volver al spawn.')
    .tooltip('§cNo se puede usar en combate.')
    .maxStackSize(64)
    .glow(true)
    .texture('minecraft:item/amethyst_shard'); // Usamos la textura de la amatista por defecto
});
