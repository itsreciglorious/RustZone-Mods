ItemEvents.rightClicked('kubejs:base_crystal', event => {
    const { player, item, level } = event;
    
    if (level.isClientSide()) return;
    
    // Validar tiempo en combate
    const lastCombatTime = player.persistentData.getLong('lastCombatTime') || 0;
    const currentTime = new Date().getTime();
    const combatDurationMs = 15000;
    
    if (currentTime - lastCombatTime < combatDurationMs) {
        const remainingTime = Math.ceil((combatDurationMs - (currentTime - lastCombatTime)) / 1000);
        player.tell(Text.red(`No puedes teletransportarte ahora. Estás en combate. (Espera ${remainingTime}s)`));
        event.cancel();
        return;
    }
    
    // Revisar si ya tiene base guardada
    const hasBase = player.persistentData.getBoolean('hasBaseCrystalPos');
    
    if (!hasBase) {
        // Establecer base (no gasta durabilidad)
        player.persistentData.putBoolean('hasBaseCrystalPos', true);
        player.persistentData.putDouble('baseX', player.x);
        player.persistentData.putDouble('baseY', player.y);
        player.persistentData.putDouble('baseZ', player.z);
        player.persistentData.putString('baseDim', level.dimension.toString());
        
        level.playSound(null, player.x, player.y, player.z, 'minecraft:block.enchantment_table.use', 'players', 1.0, 1.0);
        player.tell(Text.green('¡Punto de Retorno Personal establecido con éxito!'));
        player.tell(Text.gray('A partir de ahora, usar este cristal te traerá a este bloque.'));
    } else {
        // Teletransportarse
        const dimStr = player.persistentData.getString('baseDim');
        const bx = player.persistentData.getDouble('baseX');
        const by = player.persistentData.getDouble('baseY');
        const bz = player.persistentData.getDouble('baseZ');
        
        player.tell(Text.lightPurple('Teletransportándote a tu base...'));
        
        // Ejecutar TP a través de la consola para soportar inter-dimensiones
        player.runCommandSilent(`execute in ${dimStr} run tp ${player.username} ${bx} ${by} ${bz}`);
        
        // Reproducir sonido en el nuevo lugar
        player.runCommandSilent(`playsound minecraft:entity.enderman.teleport master ${player.username} ${bx} ${by} ${bz} 1.0 1.0`);
        
        // Gastar durabilidad
        if (!player.isCreative()) {
            item.setDamageValue(item.getDamageValue() + 1);
            if (item.getDamageValue() >= item.getMaxDamage()) {
                item.count--;
                player.playSound('minecraft:entity.item.break');
                player.tell(Text.red('Tu Cristal de Base se ha roto por el uso.'));
            }
        }
    }
});
